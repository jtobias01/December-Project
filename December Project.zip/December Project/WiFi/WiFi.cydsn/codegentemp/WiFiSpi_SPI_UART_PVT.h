/*******************************************************************************
* File Name: WiFiSpi_SPI_UART_PVT.h
* Version 2.0
*
* Description:
*  This private file provides constants and parameter values for the
*  SCB Component in SPI and UART modes.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_SPI_UART_PVT_WiFiSpi_H)
#define CY_SCB_SPI_UART_PVT_WiFiSpi_H

#include "WiFiSpi_SPI_UART.h"


/***************************************
*     Internal Global Vars
***************************************/

#if(WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST)
    extern volatile uint32  WiFiSpi_rxBufferHead;
    extern volatile uint32  WiFiSpi_rxBufferTail;
    extern volatile uint8   WiFiSpi_rxBufferOverflow;
#endif /* (WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST) */

#if(WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST)
    extern volatile uint32  WiFiSpi_txBufferHead;
    extern volatile uint32  WiFiSpi_txBufferTail;
#endif /* (WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST) */

#if(WiFiSpi_INTERNAL_RX_SW_BUFFER)
    extern volatile uint8 WiFiSpi_rxBufferInternal[WiFiSpi_RX_BUFFER_SIZE];
#endif /* (WiFiSpi_INTERNAL_RX_SW_BUFFER) */

#if(WiFiSpi_INTERNAL_TX_SW_BUFFER)
    extern volatile uint8 WiFiSpi_txBufferInternal[WiFiSpi_TX_BUFFER_SIZE];
#endif /* (WiFiSpi_INTERNAL_TX_SW_BUFFER) */


/***************************************
*     Private Function Prototypes
***************************************/

#if(WiFiSpi_SCB_MODE_SPI_CONST_CFG)
    void WiFiSpi_SpiInit(void);
#endif /* (WiFiSpi_SCB_MODE_SPI_CONST_CFG) */

#if(WiFiSpi_SPI_WAKE_ENABLE_CONST)
    void WiFiSpi_SpiSaveConfig(void);
    void WiFiSpi_SpiRestoreConfig(void);
#endif /* (WiFiSpi_SPI_WAKE_ENABLE_CONST) */

#if(WiFiSpi_SCB_MODE_UART_CONST_CFG)
    void WiFiSpi_UartInit(void);
#endif /* (WiFiSpi_SCB_MODE_UART_CONST_CFG) */

#if(WiFiSpi_UART_WAKE_ENABLE_CONST)
    void WiFiSpi_UartSaveConfig(void);
    void WiFiSpi_UartRestoreConfig(void);
    #define WiFiSpi_UartStop() \
        do{                             \
            WiFiSpi_UART_RX_CTRL_REG &= ~WiFiSpi_UART_RX_CTRL_SKIP_START; \
        }while(0)
#else
        #define WiFiSpi_UartStop() do{ /* Does nothing */ }while(0)

#endif /* (WiFiSpi_UART_WAKE_ENABLE_CONST) */

/* Interrupt processing */
#define WiFiSpi_SpiUartEnableIntRx(intSourceMask)  WiFiSpi_SetRxInterruptMode(intSourceMask)
#define WiFiSpi_SpiUartEnableIntTx(intSourceMask)  WiFiSpi_SetTxInterruptMode(intSourceMask)
uint32  WiFiSpi_SpiUartDisableIntRx(void);
uint32  WiFiSpi_SpiUartDisableIntTx(void);


/***************************************
*         UART API Constants
***************************************/

/* UART RX and TX position to be used in WiFiSpi_SetPins() */
#define WiFiSpi_UART_RX_PIN_ENABLE    (WiFiSpi_UART_RX)
#define WiFiSpi_UART_TX_PIN_ENABLE    (WiFiSpi_UART_TX)

/* UART RTS and CTS position to be used in  WiFiSpi_SetPins() */
#define WiFiSpi_UART_RTS_PIN_ENABLE    (0x10u)
#define WiFiSpi_UART_CTS_PIN_ENABLE    (0x20u)

#endif /* (CY_SCB_SPI_UART_PVT_WiFiSpi_H) */


/* [] END OF FILE */
