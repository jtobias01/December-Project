/*******************************************************************************
* File Name: SDCardSS.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SDCardSS_H) /* Pins SDCardSS_H */
#define CY_PINS_SDCardSS_H

#include "cytypes.h"
#include "cyfitter.h"
#include "SDCardSS_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    SDCardSS_Write(uint8 value) ;
void    SDCardSS_SetDriveMode(uint8 mode) ;
uint8   SDCardSS_ReadDataReg(void) ;
uint8   SDCardSS_Read(void) ;
uint8   SDCardSS_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define SDCardSS_DRIVE_MODE_BITS        (3)
#define SDCardSS_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - SDCardSS_DRIVE_MODE_BITS))

#define SDCardSS_DM_ALG_HIZ         (0x00u)
#define SDCardSS_DM_DIG_HIZ         (0x01u)
#define SDCardSS_DM_RES_UP          (0x02u)
#define SDCardSS_DM_RES_DWN         (0x03u)
#define SDCardSS_DM_OD_LO           (0x04u)
#define SDCardSS_DM_OD_HI           (0x05u)
#define SDCardSS_DM_STRONG          (0x06u)
#define SDCardSS_DM_RES_UPDWN       (0x07u)

/* Digital Port Constants */
#define SDCardSS_MASK               SDCardSS__MASK
#define SDCardSS_SHIFT              SDCardSS__SHIFT
#define SDCardSS_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define SDCardSS_PS                     (* (reg32 *) SDCardSS__PS)
/* Port Configuration */
#define SDCardSS_PC                     (* (reg32 *) SDCardSS__PC)
/* Data Register */
#define SDCardSS_DR                     (* (reg32 *) SDCardSS__DR)
/* Input Buffer Disable Override */
#define SDCardSS_INP_DIS                (* (reg32 *) SDCardSS__PC2)


#if defined(SDCardSS__INTSTAT)  /* Interrupt Registers */

    #define SDCardSS_INTSTAT                (* (reg32 *) SDCardSS__INTSTAT)

#endif /* Interrupt Registers */


/***************************************
* The following code is DEPRECATED and 
* must not be used.
***************************************/

#define SDCardSS_DRIVE_MODE_SHIFT       (0x00u)
#define SDCardSS_DRIVE_MODE_MASK        (0x07u << SDCardSS_DRIVE_MODE_SHIFT)


#endif /* End Pins SDCardSS_H */


/* [] END OF FILE */
