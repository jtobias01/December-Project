/*******************************************************************************
* File Name: WiFiLED.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_WiFiLED_H) /* Pins WiFiLED_H */
#define CY_PINS_WiFiLED_H

#include "cytypes.h"
#include "cyfitter.h"
#include "WiFiLED_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    WiFiLED_Write(uint8 value) ;
void    WiFiLED_SetDriveMode(uint8 mode) ;
uint8   WiFiLED_ReadDataReg(void) ;
uint8   WiFiLED_Read(void) ;
uint8   WiFiLED_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define WiFiLED_DRIVE_MODE_BITS        (3)
#define WiFiLED_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - WiFiLED_DRIVE_MODE_BITS))

#define WiFiLED_DM_ALG_HIZ         (0x00u)
#define WiFiLED_DM_DIG_HIZ         (0x01u)
#define WiFiLED_DM_RES_UP          (0x02u)
#define WiFiLED_DM_RES_DWN         (0x03u)
#define WiFiLED_DM_OD_LO           (0x04u)
#define WiFiLED_DM_OD_HI           (0x05u)
#define WiFiLED_DM_STRONG          (0x06u)
#define WiFiLED_DM_RES_UPDWN       (0x07u)

/* Digital Port Constants */
#define WiFiLED_MASK               WiFiLED__MASK
#define WiFiLED_SHIFT              WiFiLED__SHIFT
#define WiFiLED_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define WiFiLED_PS                     (* (reg32 *) WiFiLED__PS)
/* Port Configuration */
#define WiFiLED_PC                     (* (reg32 *) WiFiLED__PC)
/* Data Register */
#define WiFiLED_DR                     (* (reg32 *) WiFiLED__DR)
/* Input Buffer Disable Override */
#define WiFiLED_INP_DIS                (* (reg32 *) WiFiLED__PC2)


#if defined(WiFiLED__INTSTAT)  /* Interrupt Registers */

    #define WiFiLED_INTSTAT                (* (reg32 *) WiFiLED__INTSTAT)

#endif /* Interrupt Registers */


/***************************************
* The following code is DEPRECATED and 
* must not be used.
***************************************/

#define WiFiLED_DRIVE_MODE_SHIFT       (0x00u)
#define WiFiLED_DRIVE_MODE_MASK        (0x07u << WiFiLED_DRIVE_MODE_SHIFT)


#endif /* End Pins WiFiLED_H */


/* [] END OF FILE */
