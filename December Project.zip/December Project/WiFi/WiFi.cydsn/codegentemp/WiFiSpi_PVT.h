/*******************************************************************************
* File Name: .h
* Version 2.0
*
* Description:
*  This private file provides constants and parameter values for the
*  SCB Component.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PVT_WiFiSpi_H)
#define CY_SCB_PVT_WiFiSpi_H

#include "WiFiSpi.h"


/***************************************
*     Private Function Prototypes
***************************************/

/* APIs to service INTR_I2C_EC register */
#define WiFiSpi_SetI2CExtClkInterruptMode(interruptMask) WiFiSpi_WRITE_INTR_I2C_EC_MASK(interruptMask)
#define WiFiSpi_ClearI2CExtClkInterruptSource(interruptMask) WiFiSpi_CLEAR_INTR_I2C_EC(interruptMask)
#define WiFiSpi_GetI2CExtClkInterruptSource()                (WiFiSpi_INTR_I2C_EC_REG)
#define WiFiSpi_GetI2CExtClkInterruptMode()                  (WiFiSpi_INTR_I2C_EC_MASK_REG)
#define WiFiSpi_GetI2CExtClkInterruptSourceMasked()          (WiFiSpi_INTR_I2C_EC_MASKED_REG)

#if (!WiFiSpi_CY_SCBIP_V1)
    /* APIs to service INTR_SPI_EC register */
    #define WiFiSpi_SetSpiExtClkInterruptMode(interruptMask) \
                                                                WiFiSpi_WRITE_INTR_SPI_EC_MASK(interruptMask)
    #define WiFiSpi_ClearSpiExtClkInterruptSource(interruptMask) \
                                                                WiFiSpi_CLEAR_INTR_SPI_EC(interruptMask)
    #define WiFiSpi_GetExtSpiClkInterruptSource()                 (WiFiSpi_INTR_SPI_EC_REG)
    #define WiFiSpi_GetExtSpiClkInterruptMode()                   (WiFiSpi_INTR_SPI_EC_MASK_REG)
    #define WiFiSpi_GetExtSpiClkInterruptSourceMasked()           (WiFiSpi_INTR_SPI_EC_MASKED_REG)
#endif /* (!WiFiSpi_CY_SCBIP_V1) */

#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)
    extern void WiFiSpi_SetPins(uint32 mode, uint32 subMode, uint32 uartEnableMask);
#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*     Vars with External Linkage
***************************************/

#if !defined (CY_REMOVE_WiFiSpi_CUSTOM_INTR_HANDLER)
    extern cyisraddress WiFiSpi_customIntrHandler;
#endif /* !defined (CY_REMOVE_WiFiSpi_CUSTOM_INTR_HANDLER) */

extern WiFiSpi_BACKUP_STRUCT WiFiSpi_backup;

#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Common configuration variables */
    extern uint8 WiFiSpi_scbMode;
    extern uint8 WiFiSpi_scbEnableWake;
    extern uint8 WiFiSpi_scbEnableIntr;

    /* I2C configuration variables */
    extern uint8 WiFiSpi_mode;
    extern uint8 WiFiSpi_acceptAddr;

    /* SPI/UART configuration variables */
    extern volatile uint8 * WiFiSpi_rxBuffer;
    extern uint8   WiFiSpi_rxDataBits;
    extern uint32  WiFiSpi_rxBufferSize;

    extern volatile uint8 * WiFiSpi_txBuffer;
    extern uint8   WiFiSpi_txDataBits;
    extern uint32  WiFiSpi_txBufferSize;

    /* EZI2C configuration variables */
    extern uint8 WiFiSpi_numberOfAddr;
    extern uint8 WiFiSpi_subAddrSize;
#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*        Conditional Macro
****************************************/

#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Defines run time operation mode */
    #define WiFiSpi_SCB_MODE_I2C_RUNTM_CFG     (WiFiSpi_SCB_MODE_I2C      == WiFiSpi_scbMode)
    #define WiFiSpi_SCB_MODE_SPI_RUNTM_CFG     (WiFiSpi_SCB_MODE_SPI      == WiFiSpi_scbMode)
    #define WiFiSpi_SCB_MODE_UART_RUNTM_CFG    (WiFiSpi_SCB_MODE_UART     == WiFiSpi_scbMode)
    #define WiFiSpi_SCB_MODE_EZI2C_RUNTM_CFG   (WiFiSpi_SCB_MODE_EZI2C    == WiFiSpi_scbMode)
    #define WiFiSpi_SCB_MODE_UNCONFIG_RUNTM_CFG \
                                                        (WiFiSpi_SCB_MODE_UNCONFIG == WiFiSpi_scbMode)

    /* Defines wakeup enable */
    #define WiFiSpi_SCB_WAKE_ENABLE_CHECK       (0u != WiFiSpi_scbEnableWake)
#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */

/* Defines maximum number of SCB pins */
#if (!WiFiSpi_CY_SCBIP_V1)
    #define WiFiSpi_SCB_PINS_NUMBER    (7u)
#else
    #define WiFiSpi_SCB_PINS_NUMBER    (2u)
#endif /* (!WiFiSpi_CY_SCBIP_V1) */

#endif /* (CY_SCB_PVT_WiFiSpi_H) */


/* [] END OF FILE */
