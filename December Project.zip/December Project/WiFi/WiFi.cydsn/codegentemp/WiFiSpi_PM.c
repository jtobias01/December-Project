/*******************************************************************************
* File Name: WiFiSpi_PM.c
* Version 2.0
*
* Description:
*  This file provides the source code to the Power Management support for
*  the SCB Component.
*
* Note:
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "WiFiSpi.h"
#include "WiFiSpi_PVT.h"

#if(WiFiSpi_SCB_MODE_I2C_INC)
    #include "WiFiSpi_I2C_PVT.h"
#endif /* (WiFiSpi_SCB_MODE_I2C_INC) */

#if(WiFiSpi_SCB_MODE_EZI2C_INC)
    #include "WiFiSpi_EZI2C_PVT.h"
#endif /* (WiFiSpi_SCB_MODE_EZI2C_INC) */

#if(WiFiSpi_SCB_MODE_SPI_INC || WiFiSpi_SCB_MODE_UART_INC)
    #include "WiFiSpi_SPI_UART_PVT.h"
#endif /* (WiFiSpi_SCB_MODE_SPI_INC || WiFiSpi_SCB_MODE_UART_INC) */


/***************************************
*   Backup Structure declaration
***************************************/

#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG || \
   (WiFiSpi_SCB_MODE_I2C_CONST_CFG   && (!WiFiSpi_I2C_WAKE_ENABLE_CONST))   || \
   (WiFiSpi_SCB_MODE_EZI2C_CONST_CFG && (!WiFiSpi_EZI2C_WAKE_ENABLE_CONST)) || \
   (WiFiSpi_SCB_MODE_SPI_CONST_CFG   && (!WiFiSpi_SPI_WAKE_ENABLE_CONST))   || \
   (WiFiSpi_SCB_MODE_UART_CONST_CFG  && (!WiFiSpi_UART_WAKE_ENABLE_CONST)))

    WiFiSpi_BACKUP_STRUCT WiFiSpi_backup =
    {
        0u, /* enableState */
    };
#endif


/*******************************************************************************
* Function Name: WiFiSpi_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component to enter Deep Sleep.
*  The "Enable wakeup from Sleep Mode" selection has an influence on
*  this function implementation.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void WiFiSpi_Sleep(void)
{
#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)

    if(WiFiSpi_SCB_WAKE_ENABLE_CHECK)
    {
        if(WiFiSpi_SCB_MODE_I2C_RUNTM_CFG)
        {
            WiFiSpi_I2CSaveConfig();
        }
        else if(WiFiSpi_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            WiFiSpi_EzI2CSaveConfig();
        }
    #if(!WiFiSpi_CY_SCBIP_V1)
        else if(WiFiSpi_SCB_MODE_SPI_RUNTM_CFG)
        {
            WiFiSpi_SpiSaveConfig();
        }
        else if(WiFiSpi_SCB_MODE_UART_RUNTM_CFG)
        {
            WiFiSpi_UartSaveConfig();
        }
    #endif /* (!WiFiSpi_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        WiFiSpi_backup.enableState = (uint8) WiFiSpi_GET_CTRL_ENABLED;

        if(0u != WiFiSpi_backup.enableState)
        {
            WiFiSpi_Stop();
        }
    }

#else

    #if (WiFiSpi_SCB_MODE_I2C_CONST_CFG && WiFiSpi_I2C_WAKE_ENABLE_CONST)
        WiFiSpi_I2CSaveConfig();

    #elif (WiFiSpi_SCB_MODE_EZI2C_CONST_CFG && WiFiSpi_EZI2C_WAKE_ENABLE_CONST)
        WiFiSpi_EzI2CSaveConfig();

    #elif (WiFiSpi_SCB_MODE_SPI_CONST_CFG && WiFiSpi_SPI_WAKE_ENABLE_CONST)
        WiFiSpi_SpiSaveConfig();

    #elif (WiFiSpi_SCB_MODE_UART_CONST_CFG && WiFiSpi_UART_WAKE_ENABLE_CONST)
        WiFiSpi_UartSaveConfig();

    #else

        WiFiSpi_backup.enableState = (uint8) WiFiSpi_GET_CTRL_ENABLED;

        if(0u != WiFiSpi_backup.enableState)
        {
            WiFiSpi_Stop();
        }

    #endif /* defined (WiFiSpi_SCB_MODE_I2C_CONST_CFG) && (WiFiSpi_I2C_WAKE_ENABLE_CONST) */

#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: WiFiSpi_Wakeup
********************************************************************************
*
* Summary:
*  Prepares the component for the Active mode operation after exiting
*  Deep Sleep. The "Enable wakeup from Sleep Mode" option has an influence
*  on this function implementation.
*  This function should not be called after exiting Sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void WiFiSpi_Wakeup(void)
{
#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)

    if(WiFiSpi_SCB_WAKE_ENABLE_CHECK)
    {
        if(WiFiSpi_SCB_MODE_I2C_RUNTM_CFG)
        {
            WiFiSpi_I2CRestoreConfig();
        }
        else if(WiFiSpi_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            WiFiSpi_EzI2CRestoreConfig();
        }
    #if(!WiFiSpi_CY_SCBIP_V1)
        else if(WiFiSpi_SCB_MODE_SPI_RUNTM_CFG)
        {
            WiFiSpi_SpiRestoreConfig();
        }
        else if(WiFiSpi_SCB_MODE_UART_RUNTM_CFG)
        {
            WiFiSpi_UartRestoreConfig();
        }
    #endif /* (!WiFiSpi_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        if(0u != WiFiSpi_backup.enableState)
        {
            WiFiSpi_Enable();
        }
    }

#else

    #if (WiFiSpi_SCB_MODE_I2C_CONST_CFG  && WiFiSpi_I2C_WAKE_ENABLE_CONST)
        WiFiSpi_I2CRestoreConfig();

    #elif (WiFiSpi_SCB_MODE_EZI2C_CONST_CFG && WiFiSpi_EZI2C_WAKE_ENABLE_CONST)
        WiFiSpi_EzI2CRestoreConfig();

    #elif (WiFiSpi_SCB_MODE_SPI_CONST_CFG && WiFiSpi_SPI_WAKE_ENABLE_CONST)
        WiFiSpi_SpiRestoreConfig();

    #elif (WiFiSpi_SCB_MODE_UART_CONST_CFG && WiFiSpi_UART_WAKE_ENABLE_CONST)
        WiFiSpi_UartRestoreConfig();

    #else

        if(0u != WiFiSpi_backup.enableState)
        {
            WiFiSpi_Enable();
        }

    #endif /* (WiFiSpi_I2C_WAKE_ENABLE_CONST) */

#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/* [] END OF FILE */
