/* ========================================
 *
 The following firmware was developed by Cypress Semiconductor
This work is licensed under a Creative Commons Attribution 3.0 Unported License.
http://creativecommons.org/licenses/by/3.0/deed.en_US
You are free to:
-To Share — to copy, distribute and transmit the work 
-To Remix — to adapt the work 
-To make commercial use of the work
* ========================================
*/

#define HTTP_HEADER "HTTP/1.1 200 OK\r\nContent-type:text/html\r\n\r\n"
#define HTTP_FOOTER "\r\n\r\n"
#define HEAD1   "<HTML><HEAD>"
#define HEAD2   "<TITLE>PSoC4 Control</TITLE>"
#define HEAD3   "<meta name=viewport content='width=150; initial-scale=1; user-scalable=0;'>"
#define HEAD4   "<style>input[type='range']{height: 44px; width: 100%;}"
#define HEAD5       "input[type='range']::-webkit-slider-thumb{width: 44px; height: 44px;}td{font-size: 46px;}</style>"
#define HEAD6   "<script> var int=null;"
#define HEAD7       "var timeout=500;"
#define HEAD8       "var xmlHttp = new XMLHttpRequest();"
#define HEAD9       "var foo=null; var attempts = 0;"
#define HEAD10      "var var_r = 0; var var_r_last = 0;"
#define HEAD11      "var var_b = 0; var var_b_last = 0;"
#define HEAD12      "var var_g = 0; var var_g_last = 0;"
#define HEAD13      "function SendData(){ if(var_r == var_r_last && var_b == var_b_last && var_g == var_g_last){if(attempts>3) return; attempts++;} "
#define HEAD14          "xmlHttp.abort();"
#define HEAD15          "xmlHttp = new XMLHttpRequest();"
#define HEAD16          "xmlHttp.open('GET', '/r?r=' + var_r + '&b=' + var_b + '&g=' + var_g, true); var_r_last=var_r; var_b_last=var_b; var_g_last=var_g;"
#define HEAD17          "xmlHttp.send(null);"
#define HEAD18      "}"
#define HEAD19      "int = window.setInterval(function(){SendData();},1000);"
#define HEAD20  "</script>"
#define HEAD21  "</head>"
#define HEAD    HEAD1 HEAD2 HEAD3 HEAD4 HEAD5 HEAD6 HEAD7 HEAD8 HEAD9 HEAD10 HEAD11 HEAD12 HEAD13 HEAD14 HEAD15 HEAD16 HEAD17 HEAD18 HEAD19 HEAD20 HEAD21
#define BODY    "<body><table border='0' width='100%' height='100%'>"
#define FOOTER  "<script></script></table></body></html>"
#define TR_START    "<TR height='33%'>"
#define COL1_START  "<TD>"
#define COL1_END    ":</td>\r\n"
#define COL2_START  "<td width='100%'>"
#define INPUT_START "<input type='range' min='0' max='99' width='100%' onChange='attempts=0; var_"
#define INPUT_DATA "=this.value;' value='"
#define INPUT_END   "'/>"
#define SCRIPT_START "<script>var_"
#define SCRIPT_DATA  "="
#define SCRIPT_END   ";</script>"
#define COL2_END    "</TD>"
#define TR_END      "</TR>\r\n"
//[] END OF FILE
