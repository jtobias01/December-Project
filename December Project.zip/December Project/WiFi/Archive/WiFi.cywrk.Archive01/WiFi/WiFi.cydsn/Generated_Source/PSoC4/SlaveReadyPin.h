/*******************************************************************************
* File Name: SlaveReadyPin.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SlaveReadyPin_H) /* Pins SlaveReadyPin_H */
#define CY_PINS_SlaveReadyPin_H

#include "cytypes.h"
#include "cyfitter.h"
#include "SlaveReadyPin_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    SlaveReadyPin_Write(uint8 value) ;
void    SlaveReadyPin_SetDriveMode(uint8 mode) ;
uint8   SlaveReadyPin_ReadDataReg(void) ;
uint8   SlaveReadyPin_Read(void) ;
uint8   SlaveReadyPin_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define SlaveReadyPin_DRIVE_MODE_BITS        (3)
#define SlaveReadyPin_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - SlaveReadyPin_DRIVE_MODE_BITS))
#define SlaveReadyPin_DRIVE_MODE_SHIFT       (0x00u)
#define SlaveReadyPin_DRIVE_MODE_MASK        (0x07u << SlaveReadyPin_DRIVE_MODE_SHIFT)

#define SlaveReadyPin_DM_ALG_HIZ         (0x00u << SlaveReadyPin_DRIVE_MODE_SHIFT)
#define SlaveReadyPin_DM_DIG_HIZ         (0x01u << SlaveReadyPin_DRIVE_MODE_SHIFT)
#define SlaveReadyPin_DM_RES_UP          (0x02u << SlaveReadyPin_DRIVE_MODE_SHIFT)
#define SlaveReadyPin_DM_RES_DWN         (0x03u << SlaveReadyPin_DRIVE_MODE_SHIFT)
#define SlaveReadyPin_DM_OD_LO           (0x04u << SlaveReadyPin_DRIVE_MODE_SHIFT)
#define SlaveReadyPin_DM_OD_HI           (0x05u << SlaveReadyPin_DRIVE_MODE_SHIFT)
#define SlaveReadyPin_DM_STRONG          (0x06u << SlaveReadyPin_DRIVE_MODE_SHIFT)
#define SlaveReadyPin_DM_RES_UPDWN       (0x07u << SlaveReadyPin_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define SlaveReadyPin_MASK               SlaveReadyPin__MASK
#define SlaveReadyPin_SHIFT              SlaveReadyPin__SHIFT
#define SlaveReadyPin_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define SlaveReadyPin_PS                     (* (reg32 *) SlaveReadyPin__PS)
/* Port Configuration */
#define SlaveReadyPin_PC                     (* (reg32 *) SlaveReadyPin__PC)
/* Data Register */
#define SlaveReadyPin_DR                     (* (reg32 *) SlaveReadyPin__DR)
/* Input Buffer Disable Override */
#define SlaveReadyPin_INP_DIS                (* (reg32 *) SlaveReadyPin__PC2)


#if defined(SlaveReadyPin__INTSTAT)  /* Interrupt Registers */

    #define SlaveReadyPin_INTSTAT                (* (reg32 *) SlaveReadyPin__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins SlaveReadyPin_H */


/* [] END OF FILE */
