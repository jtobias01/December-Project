/*******************************************************************************
* File Name: WiFiSpi_SPI.c
* Version 1.0
*
* Description:
*  This file provides the source code to the API for the SCB Component in
*  SPI mode.
*
* Note:
*
*******************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "WiFiSpi_PVT.h"
#include "WiFiSpi_SPI_UART_PVT.h"

#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)

    /***************************************
    *  Config Structure Initialization
    ***************************************/

    const WiFiSpi_SPI_INIT_STRUCT WiFiSpi_configSpi =
    {
        WiFiSpi_SPI_MODE,
        WiFiSpi_SPI_SUB_MODE,
        WiFiSpi_SPI_CLOCK_MODE,
        WiFiSpi_SPI_OVS_FACTOR,
        WiFiSpi_SPI_MEDIAN_FILTER_ENABLE,
        WiFiSpi_SPI_LATE_MISO_SAMPLE_ENABLE,
        WiFiSpi_SPI_WAKE_ENABLE,
        WiFiSpi_SPI_RX_DATA_BITS_NUM,
        WiFiSpi_SPI_TX_DATA_BITS_NUM,
        WiFiSpi_SPI_BITS_ORDER,
        WiFiSpi_SPI_TRANSFER_SEPARATION,
        0u,
        NULL,
        0u,
        NULL,
        WiFiSpi_SPI_INTERRUPT_ENABLE,
        WiFiSpi_SPI_INTR_RX_MASK,
        WiFiSpi_SPI_RX_TRIGGER_LEVEL,
        WiFiSpi_SPI_INTR_TX_MASK,
        WiFiSpi_SPI_TX_TRIGGER_LEVEL
    };


    /*******************************************************************************
    * Function Name: WiFiSpi_SpiInit
    ********************************************************************************
    *
    * Summary:
    *  Configures the SCB for SPI operation.
    *
    * Parameters:
    *  config:  Pointer to a structure that contains the following ordered list of
    *           fields. These fields match the selections available in the
    *           customizer.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void WiFiSpi_SpiInit(const WiFiSpi_SPI_INIT_STRUCT *config)
    {
        if(NULL == config)
        {
            CYASSERT(0u != 0u); /* Halt execution due bad fucntion parameter */
        }
        else
        {
            /* Configure pins */
            WiFiSpi_SetPins(WiFiSpi_SCB_MODE_SPI, config->mode, WiFiSpi_DUMMY_PARAM);

            /* Store internal configuration */
            WiFiSpi_scbMode       = (uint8) WiFiSpi_SCB_MODE_SPI;
            WiFiSpi_scbEnableWake = (uint8) config->enableWake;

            /* Set RX direction internal variables */
            WiFiSpi_rxBuffer      =         config->rxBuffer;
            WiFiSpi_rxDataBits    = (uint8) config->rxDataBits;
            WiFiSpi_rxBufferSize  = (uint8) config->rxBufferSize;

            /* Set TX direction internal variables */
            WiFiSpi_txBuffer      =         config->txBuffer;
            WiFiSpi_txDataBits    = (uint8) config->txDataBits;
            WiFiSpi_txBufferSize  = (uint8) config->txBufferSize;


            /* Configure SPI interface */
            WiFiSpi_CTRL_REG     = WiFiSpi_GET_CTRL_OVS(config->oversample)        |
                                            WiFiSpi_GET_CTRL_EC_AM_MODE(config->enableWake) |
                                            WiFiSpi_CTRL_SPI;

            WiFiSpi_SPI_CTRL_REG = WiFiSpi_GET_SPI_CTRL_CONTINUOUS    (config->transferSeperation)  |
                                            WiFiSpi_GET_SPI_CTRL_SELECT_PRECEDE(config->submode & 
                                                                          WiFiSpi_SPI_MODE_TI_PRECEDES_MASK) |
                                            WiFiSpi_GET_SPI_CTRL_SCLK_MODE     (config->sclkMode)            |
                                            WiFiSpi_GET_SPI_CTRL_LATE_MISO_SAMPLE(config->enableLateSampling)|
                                            WiFiSpi_GET_SPI_CTRL_SUB_MODE      (config->submode)             |
                                            WiFiSpi_GET_SPI_CTRL_MASTER_MODE   (config->mode);

            /* Configure RX direction */
            WiFiSpi_RX_CTRL_REG     =  WiFiSpi_GET_RX_CTRL_DATA_WIDTH(config->rxDataBits)         |
                                                WiFiSpi_GET_RX_CTRL_BIT_ORDER (config->bitOrder)           |
                                                WiFiSpi_GET_RX_CTRL_MEDIAN    (config->enableMedianFilter) |
                                                WiFiSpi_SPI_RX_CTRL;

            WiFiSpi_RX_FIFO_CTRL_REG = WiFiSpi_GET_RX_FIFO_CTRL_TRIGGER_LEVEL(config->rxTriggerLevel);

            /* Configure TX direction */
            WiFiSpi_TX_CTRL_REG      = WiFiSpi_GET_TX_CTRL_DATA_WIDTH(config->txDataBits) |
                                                WiFiSpi_GET_TX_CTRL_BIT_ORDER (config->bitOrder)   |
                                                WiFiSpi_SPI_TX_CTRL;

            WiFiSpi_TX_FIFO_CTRL_REG = WiFiSpi_GET_TX_FIFO_CTRL_TRIGGER_LEVEL(config->txTriggerLevel);

            /* Configure interrupt sources */
            WiFiSpi_INTR_I2C_EC_MASK_REG = WiFiSpi_NO_INTR_SOURCES;
            WiFiSpi_INTR_SPI_EC_MASK_REG = WiFiSpi_NO_INTR_SOURCES;
            WiFiSpi_INTR_SLAVE_MASK_REG  = WiFiSpi_GET_SPI_INTR_SLAVE_MASK(config->rxInterruptMask);
            WiFiSpi_INTR_MASTER_MASK_REG = WiFiSpi_GET_SPI_INTR_MASTER_MASK(config->txInterruptMask);
            WiFiSpi_INTR_RX_MASK_REG     = WiFiSpi_GET_SPI_INTR_RX_MASK(config->rxInterruptMask);
            WiFiSpi_INTR_TX_MASK_REG     = WiFiSpi_GET_SPI_INTR_TX_MASK(config->txInterruptMask);

            /* Configure interrupt source */
            WiFiSpi_SCB_IRQ_StartEx(&WiFiSpi_SPI_UART_ISR);
            if(0u == config->enableInterrupt)
            {
                WiFiSpi_SCB_IRQ_Disable();
            }


            /* Clear RX buffer indexes */
            WiFiSpi_rxBufferHead     = 0u;
            WiFiSpi_rxBufferTail     = 0u;
            WiFiSpi_rxBufferOverflow = 0u;

            /* Clrea TX buffer indexes */
            WiFiSpi_txBufferHead = 0u;
            WiFiSpi_txBufferTail = 0u;
        }
    }

#else

    /*******************************************************************************
    * Function Name: WiFiSpi_SpiInit
    ********************************************************************************
    *
    * Summary:
    *  Configures the SCB for SPI operation.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void WiFiSpi_SpiInit(void)
    {
        /* Configure SPI interface */
        WiFiSpi_CTRL_REG     = WiFiSpi_SPI_DEFAULT_CTRL;
        WiFiSpi_SPI_CTRL_REG = WiFiSpi_SPI_DEFAULT_SPI_CTRL;

        /* Configure TX and RX direction */
        WiFiSpi_RX_CTRL_REG      = WiFiSpi_SPI_DEFAULT_RX_CTRL;
        WiFiSpi_RX_FIFO_CTRL_REG = WiFiSpi_SPI_DEFAULT_RX_FIFO_CTRL;

        /* Configure TX and RX direction */
        WiFiSpi_TX_CTRL_REG      = WiFiSpi_SPI_DEFAULT_TX_CTRL;
        WiFiSpi_TX_FIFO_CTRL_REG = WiFiSpi_SPI_DEFAULT_TX_FIFO_CTRL;

        /* Configure interrupt sources */
        WiFiSpi_INTR_I2C_EC_MASK_REG = WiFiSpi_SPI_DEFAULT_INTR_I2C_EC_MASK;
        WiFiSpi_INTR_SPI_EC_MASK_REG = WiFiSpi_SPI_DEFAULT_INTR_SPI_EC_MASK;
        WiFiSpi_INTR_SLAVE_MASK_REG  = WiFiSpi_SPI_DEFAULT_INTR_SLAVE_MASK;
        WiFiSpi_INTR_MASTER_MASK_REG = WiFiSpi_SPI_DEFAULT_INTR_MASTER_MASK;
        WiFiSpi_INTR_RX_MASK_REG     = WiFiSpi_SPI_DEFAULT_INTR_RX_MASK;
        WiFiSpi_INTR_TX_MASK_REG     = WiFiSpi_SPI_DEFAULT_INTR_TX_MASK;


        /* Configure interrupt source */
        #if(WiFiSpi_SCB_IRQ_INTERNAL)
            WiFiSpi_SCB_IRQ_StartEx(&WiFiSpi_SPI_UART_ISR);

            #if(WiFiSpi_SPI_INTERRUPT_DISABLE)
                WiFiSpi_SCB_IRQ_Disable();
            #endif /* (WiFiSpi_SPI_INTERRUPT_DISABLE) */
        #endif /* (WiFiSpi_SCB_IRQ_INTERNAL) */


        #if(WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST)
            WiFiSpi_rxBufferHead     = 0u;
            WiFiSpi_rxBufferTail     = 0u;
            WiFiSpi_rxBufferOverflow = 0u;
        #endif /* (WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST) */

        #if(WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST)
            WiFiSpi_txBufferHead = 0u;
            WiFiSpi_txBufferTail = 0u;
        #endif /* (WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST) */
    }

#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */


/*******************************************************************************
* Function Name: WiFiSpi_SetActiveSlaveSelect
********************************************************************************
*
* Summary:
*  Selects one of the four SPI slave select signals.
*  The component should be in one of the following states to change the active
*  slave select signal source correctly:
*   - the component is disabled
*   - the component has completed all transactions (TX FIFO is empty and the
*     SpiDone flag is set)
*  This function does not check that these conditions are met.
*  At initialization time the active slave select line is slave select 0.
*
* Parameters:
*  activeSelect: The four lines available to utilize Slave Select function.
*
* Return:
*  None
*
*******************************************************************************/
void WiFiSpi_SpiSetActiveSlaveSelect(uint32 activeSelect)
{
    uint32 spiCtrl;
    
    spiCtrl = WiFiSpi_SPI_CTRL_REG;
    
    spiCtrl &= (uint32) ~WiFiSpi_SPI_CTRL_SLAVE_SELECT_MASK; /* Clear SS bits */
    spiCtrl |= (uint32)  WiFiSpi_GET_SPI_CTRL_SS(activeSelect);
    
    WiFiSpi_SPI_CTRL_REG = spiCtrl;
}


/*******************************************************************************
* Function Name: WiFiSpi_SpiSaveConfig
********************************************************************************
*
* Summary:
*  Wakeup disabled: does nothing.
*  Wakeup  enabled: clears SCB_backup.enableState to keep component enabled
*  while DeepSleep. The SCB_INTR_SPI_EC_WAKE_UP enabled while initialization
*  and tracks in active mode therefore it does not require to be cleared.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  None
*
*******************************************************************************/
void WiFiSpi_SpiSaveConfig(void)
{
    #if(WiFiSpi_CHECK_SPI_WAKE_ENABLE)
    {
        WiFiSpi_backup.enableState = 0u; /* Keep SCB enabled */
        
        /* Clear wake-up before enable */
        WiFiSpi_ClearSpiExtClkInterruptSource(WiFiSpi_INTR_SPI_EC_WAKE_UP);
        
        /* Enable interrupt to wakeup the device */
        WiFiSpi_SetSpiExtClkInterruptMode(WiFiSpi_INTR_SPI_EC_WAKE_UP);
    }
    #endif
}


/*******************************************************************************
* Function Name: WiFiSpi_SpiRestoreConfig
********************************************************************************
*
* Summary:
*  Does nothing.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  None
*
*******************************************************************************/
void WiFiSpi_SpiRestoreConfig(void)
{
    #if(WiFiSpi_CHECK_SPI_WAKE_ENABLE)
    {
        /* Disable interrupt to wakeup the device */
        WiFiSpi_SetSpiExtClkInterruptMode(WiFiSpi_NO_INTR_SOURCES);
    }
    #endif
}


/* [] END OF FILE */
