/*******************************************************************************
* File Name: WiFiSpi_PM.c
* Version 1.0
*
* Description:
*  This file provides the source code to the Power Management support for
*  the SCB Component.
*
* Note:
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "WiFiSpi.h"

#if(WiFiSpi_SCB_MODE_I2C_INC)
    #include "WiFiSpi_I2C_PVT.h"
#endif /* (WiFiSpi_SCB_MODE_I2C_INC) */

#if(WiFiSpi_SCB_MODE_SPI_INC || WiFiSpi_SCB_MODE_UART_INC)
    #include "WiFiSpi_SPI_UART_PVT.h"
#endif /* (WiFiSpi_SCB_MODE_SPI_INC || WiFiSpi_SCB_MODE_UART_INC) */


/***************************************
*   Backup Structure declaration
***************************************/

WiFiSpi_BACKUP_STRUCT WiFiSpi_backup =
{
    0u, /* enableState */
};


/*******************************************************************************
* Function Name: WiFiSpi_Sleep
********************************************************************************
*
* Summary:
*  Calls SaveConfig function fucntion for selected mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void WiFiSpi_Sleep(void)
{
    WiFiSpi_backup.enableState = (uint8) WiFiSpi_GET_CTRL_ENABLED;

    #if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)

        if(WiFiSpi_SCB_MODE_I2C_RUNTM_CFG)
        {
            WiFiSpi_I2CSaveConfig();
        }
        else if(WiFiSpi_SCB_MODE_SPI_RUNTM_CFG)
        {
            WiFiSpi_SpiSaveConfig();
        }
        else if(WiFiSpi_SCB_MODE_UART_RUNTM_CFG)
        {
            WiFiSpi_UartSaveConfig();
        }
        else
        {
            /* Unknown mode: do nothing */
        }

    #elif(WiFiSpi_SCB_MODE_I2C_CONST_CFG)
        WiFiSpi_I2CSaveConfig();

    #elif(WiFiSpi_SCB_MODE_SPI_CONST_CFG)
        WiFiSpi_SpiSaveConfig();

    #elif(WiFiSpi_SCB_MODE_UART_CONST_CFG)
        WiFiSpi_UartSaveConfig();

    #else
        /* Do nothing */

    #endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */

    if(0u != WiFiSpi_backup.enableState)
    {
        WiFiSpi_Stop();
    }
}


/*******************************************************************************
* Function Name: WiFiSpi_Wakeup
********************************************************************************
*
* Summary:
*  Calls RestoreConfig function fucntion for selected mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void WiFiSpi_Wakeup(void)
{
    #if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)

        if(WiFiSpi_SCB_MODE_I2C_RUNTM_CFG)
        {
            WiFiSpi_I2CRestoreConfig();
        }
        else if(WiFiSpi_SCB_MODE_SPI_RUNTM_CFG)
        {
            WiFiSpi_SpiRestoreConfig();
        }
        else if(WiFiSpi_SCB_MODE_UART_RUNTM_CFG)
        {
            WiFiSpi_UartRestoreConfig();
        }
        else
        {
            /* Unknown mode: do nothing */
        }

    #elif(WiFiSpi_SCB_MODE_I2C_CONST_CFG)
        WiFiSpi_I2CRestoreConfig();

    #elif(WiFiSpi_SCB_MODE_SPI_CONST_CFG)
        WiFiSpi_SpiRestoreConfig();

    #elif(WiFiSpi_SCB_MODE_UART_CONST_CFG)
        WiFiSpi_UartRestoreConfig();

    #else
        /* Do nothing */

    #endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */

    if(0u != WiFiSpi_backup.enableState)
    {
        WiFiSpi_Enable();
    }
}


/* [] END OF FILE */
