/*******************************************************************************
* File Name: .h
* Version 1.0
*
* Description:
*  This private file provides constants and parameter values for the
*  SCB Component in I2C mode.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PVT_WiFiSpi_H)
#define CY_SCB_PVT_WiFiSpi_H

#include "WiFiSpi.h"


/***************************************
*     Private Function Prototypes
***************************************/

/* APIs to service INTR_I2C_EC register */
#define WiFiSpi_SetI2CExtClkInterruptMode(interruptMask) WiFiSpi_WRITE_INTR_I2C_EC_MASK(interruptMask)
#define WiFiSpi_ClearI2CExtClkInterruptSource(interruptMask) WiFiSpi_CLEAR_INTR_I2C_EC(interruptMask)
#define WiFiSpi_GetI2CExtClkInterruptSource()                (WiFiSpi_INTR_I2C_EC_REG)
#define WiFiSpi_GetI2CExtClkInterruptMode()                  (WiFiSpi_INTR_I2C_EC_MASK_REG)
#define WiFiSpi_GetI2CExtClkInterruptSourceMasked()          (WiFiSpi_INTR_I2C_EC_MASKED_REG)

/* APIs to service INTR_SPI_EC register */
#define WiFiSpi_SetSpiExtClkInterruptMode(interruptMask) WiFiSpi_WRITE_INTR_SPI_EC_MASK(interruptMask)
#define WiFiSpi_ClearSpiExtClkInterruptSource(interruptMask) WiFiSpi_CLEAR_INTR_SPI_EC(interruptMask)
#define WiFiSpi_GetExtSpiClkInterruptSource()                 (WiFiSpi_INTR_SPI_EC_REG)
#define WiFiSpi_GetExtSpiClkInterruptMode()                   (WiFiSpi_INTR_SPI_EC_MASK_REG)
#define WiFiSpi_GetExtSpiClkInterruptSourceMasked()           (WiFiSpi_INTR_SPI_EC_MASKED_REG)

#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)
    extern void WiFiSpi_SetPins(uint32 mode, uint32 subMode, uint32 uartTxRx);
#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */

#endif /* (CY_SCB_PVT_WiFiSpi_H) */


/* [] END OF FILE */
