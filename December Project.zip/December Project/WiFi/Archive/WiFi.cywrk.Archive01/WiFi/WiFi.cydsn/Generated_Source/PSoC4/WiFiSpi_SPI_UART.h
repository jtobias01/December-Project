/*******************************************************************************
* File Name: WiFiSpi_SPI_UART.h
* Version 1.0
*
* Description:
*  This file provides constants and parameter values for the SCB Component in
*  SPI and UART modes.
*
* Note:
*
********************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_SPI_UART_WiFiSpi_H)
#define CY_SCB_SPI_UART_WiFiSpi_H

#include "WiFiSpi.h"


/***************************************
*   SPI Initial Parameter Constants
****************************************/

#define WiFiSpi_SPI_MODE                   (1u)
#define WiFiSpi_SPI_SUB_MODE               (0u)
#define WiFiSpi_SPI_CLOCK_MODE             (0u)
#define WiFiSpi_SPI_OVS_FACTOR             (8u)
#define WiFiSpi_SPI_MEDIAN_FILTER_ENABLE   (0u)
#define WiFiSpi_SPI_LATE_MISO_SAMPLE_ENABLE (0u)
#define WiFiSpi_SPI_RX_DATA_BITS_NUM       (8u)
#define WiFiSpi_SPI_TX_DATA_BITS_NUM       (8u)
#define WiFiSpi_SPI_WAKE_ENABLE            (0u)
#define WiFiSpi_SPI_BITS_ORDER             (1u)
#define WiFiSpi_SPI_TRANSFER_SEPARATION    (1u)
#define WiFiSpi_SPI_NUMBER_OF_SS_LINES     (1u)
#define WiFiSpi_SPI_RX_BUFFER_SIZE         (8u)
#define WiFiSpi_SPI_TX_BUFFER_SIZE         (8u)

#define WiFiSpi_SPI_INTERRUPT_MODE         (0u)

#define WiFiSpi_SPI_INTR_RX_MASK           (0u)
#define WiFiSpi_SPI_INTR_TX_MASK           (0u)

#define WiFiSpi_SPI_RX_TRIGGER_LEVEL       (7u)
#define WiFiSpi_SPI_TX_TRIGGER_LEVEL       (0u)


/***************************************
*   UART Initial Parameter Constants
****************************************/

#define WiFiSpi_UART_SUB_MODE              (0u)
#define WiFiSpi_UART_DIRECTION             (3u)
#define WiFiSpi_UART_DATA_BITS_NUM         (8u)
#define WiFiSpi_UART_PARITY_TYPE           (2u)
#define WiFiSpi_UART_STOP_BITS_NUM         (2u)
#define WiFiSpi_UART_OVS_FACTOR            (12u)
#define WiFiSpi_UART_IRDA_LOW_POWER        (0u)
#define WiFiSpi_UART_MEDIAN_FILTER_ENABLE  (0u)
#define WiFiSpi_UART_RETRY_ON_NACK         (0u)
#define WiFiSpi_UART_IRDA_POLARITY         (0u)
#define WiFiSpi_UART_DROP_ON_FRAME_ERR     (0u)
#define WiFiSpi_UART_DROP_ON_PARITY_ERR    (0u)
#define WiFiSpi_UART_WAKE_ENABLE           (0u)
#define WiFiSpi_UART_RX_BUFFER_SIZE        (8u)
#define WiFiSpi_UART_TX_BUFFER_SIZE        (8u)
#define WiFiSpi_UART_MP_MODE_ENABLE        (0u)
#define WiFiSpi_UART_MP_ACCEPT_ADDRESS     (0u)
#define WiFiSpi_UART_MP_RX_ADDRESS         (2u)
#define WiFiSpi_UART_MP_RX_ADDRESS_MASK    (255u)

#define WiFiSpi_UART_INTERRUPT_MODE        (0u)

#define WiFiSpi_UART_INTR_RX_MASK          (0u)
#define WiFiSpi_UART_INTR_TX_MASK          (0u)

#define WiFiSpi_UART_RX_TRIGGER_LEVEL      (7u)
#define WiFiSpi_UART_TX_TRIGGER_LEVEL      (0u)

/* Sources of RX errors */
#define WiFiSpi_INTR_RX_ERR        (WiFiSpi_INTR_RX_OVERFLOW    | \
                                             WiFiSpi_INTR_RX_UNDERFLOW   | \
                                             WiFiSpi_INTR_RX_FRAME_ERROR | \
                                             WiFiSpi_INTR_RX_PARITY_ERROR)

/* UART direction enum */
#define WiFiSpi_UART_RX    (1u)
#define WiFiSpi_UART_TX    (2u)
#define WiFiSpi_UART_TX_RX (3u)


/***************************************
*   Conditional Compilation Parameters
****************************************/

/* Enable SPI mode interrupt */
#define WiFiSpi_SPI_INTERRUPT_ENABLE   ((WiFiSpi_SPI_INTERRUPT_MODE == \
                                                    WiFiSpi_SCB_INTR_MODE_INTERNAL) ? (1u) : (0u))

/* Enable UART mode interrupt */
#define WiFiSpi_UART_INTERRUPT_ENABLE  ((WiFiSpi_UART_INTERRUPT_MODE == \
                                                    WiFiSpi_SCB_INTR_MODE_INTERNAL) ? (1u) : (0u))

#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)

    /* Direction */
    #define WiFiSpi_RX_DIRECTION           (1u)
    #define WiFiSpi_TX_DIRECTION           (1u)
    #define WiFiSpi_UART_RX_DIRECTION      (1u)
    #define WiFiSpi_UART_TX_DIRECTION      (1u)

    /* Only external RX and TX buffer for uncofigured mode */
    #define WiFiSpi_INTERNAL_RX_SW_BUFFER   (0u)
    #define WiFiSpi_INTERNAL_TX_SW_BUFFER   (0u)

    /* Get RX and TX buffer size */
    #define WiFiSpi_RX_BUFFER_SIZE (WiFiSpi_rxBufferSize)
    #define WiFiSpi_TX_BUFFER_SIZE (WiFiSpi_txBufferSize)

    /* Return true if buffer is provided */
    #define WiFiSpi_CHECK_RX_SW_BUFFER (NULL != WiFiSpi_rxBuffer)
    #define WiFiSpi_CHECK_TX_SW_BUFFER (NULL != WiFiSpi_txBuffer)

    /* Alwasy provde global variables to support RX and TX buffers */
    #define WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST    (1u)
    #define WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST    (1u)

    /* Get wakeup enable option */
    #define WiFiSpi_CHECK_SPI_WAKE_ENABLE  (0u != WiFiSpi_scbEnableWake)
    #define WiFiSpi_CHECK_UART_WAKE_ENABLE (0u != WiFiSpi_scbEnableWake)

#else

    /* SPI internal RX and TX buffers */
    #define WiFiSpi_INTERNAL_SPI_RX_SW_BUFFER  (WiFiSpi_SPI_RX_BUFFER_SIZE > \
                                                                                            WiFiSpi_FIFO_SIZE)
    #define WiFiSpi_INTERNAL_SPI_TX_SW_BUFFER  (WiFiSpi_SPI_TX_BUFFER_SIZE > \
                                                                                            WiFiSpi_FIFO_SIZE)

    /* UART internal RX and TX buffers */
    #define WiFiSpi_INTERNAL_UART_RX_SW_BUFFER  (WiFiSpi_UART_RX_BUFFER_SIZE > \
                                                                                            WiFiSpi_FIFO_SIZE)
    #define WiFiSpi_INTERNAL_UART_TX_SW_BUFFER  (WiFiSpi_UART_TX_BUFFER_SIZE > \
                                                                                            WiFiSpi_FIFO_SIZE)

    /* SPI Direction */
    #define WiFiSpi_SPI_RX_DIRECTION (1u)
    #define WiFiSpi_SPI_TX_DIRECTION (1u)

    /* UART Direction */
    #define WiFiSpi_UART_RX_DIRECTION (0u != (WiFiSpi_UART_DIRECTION & WiFiSpi_UART_RX))
    #define WiFiSpi_UART_TX_DIRECTION (0u != (WiFiSpi_UART_DIRECTION & WiFiSpi_UART_TX))

    /* Direction */
    #define WiFiSpi_RX_DIRECTION ((WiFiSpi_SCB_MODE_SPI_CONST_CFG) ? \
                                            (WiFiSpi_SPI_RX_DIRECTION) : (WiFiSpi_UART_RX_DIRECTION))

    #define WiFiSpi_TX_DIRECTION ((WiFiSpi_SCB_MODE_SPI_CONST_CFG) ? \
                                            (WiFiSpi_SPI_TX_DIRECTION) : (WiFiSpi_UART_TX_DIRECTION))

    /* Internal RX and TX buffer: for SPI or UART */
    #if(WiFiSpi_SCB_MODE_SPI_CONST_CFG)

        /* Internal SPI RX and TX buffer */
        #define WiFiSpi_INTERNAL_RX_SW_BUFFER  (WiFiSpi_INTERNAL_SPI_RX_SW_BUFFER)
        #define WiFiSpi_INTERNAL_TX_SW_BUFFER  (WiFiSpi_INTERNAL_SPI_TX_SW_BUFFER)

        /* Internal SPI RX and TX buffer size */
        #define WiFiSpi_RX_BUFFER_SIZE         (WiFiSpi_SPI_RX_BUFFER_SIZE + 1u)
        #define WiFiSpi_TX_BUFFER_SIZE         (WiFiSpi_SPI_TX_BUFFER_SIZE)

    #else

        /* Internal UART RX and TX buffer */
        #define WiFiSpi_INTERNAL_RX_SW_BUFFER  (WiFiSpi_INTERNAL_UART_RX_SW_BUFFER)
        #define WiFiSpi_INTERNAL_TX_SW_BUFFER  (WiFiSpi_INTERNAL_UART_TX_SW_BUFFER)

        /* Internal UART RX and TX buffer size */
        #define WiFiSpi_RX_BUFFER_SIZE         (WiFiSpi_UART_RX_BUFFER_SIZE + 1u)
        #define WiFiSpi_TX_BUFFER_SIZE         (WiFiSpi_UART_TX_BUFFER_SIZE)

    #endif /* (WiFiSpi_SCB_MODE_SPI_CONST_CFG) */

    /* Internal RX and TX buffer: for SPI or UART. Used in conditional compilation check */
    #define WiFiSpi_CHECK_RX_SW_BUFFER (WiFiSpi_INTERNAL_RX_SW_BUFFER)
    #define WiFiSpi_CHECK_TX_SW_BUFFER (WiFiSpi_INTERNAL_TX_SW_BUFFER)

    /* Provide global variables to support RX and TX buffers */
    #define WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST    (WiFiSpi_INTERNAL_RX_SW_BUFFER)
    #define WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST    (WiFiSpi_INTERNAL_TX_SW_BUFFER)

    /* Get wakeup enable option */
    #define WiFiSpi_CHECK_SPI_WAKE_ENABLE  (0u != WiFiSpi_SPI_WAKE_ENABLE)
    #define WiFiSpi_CHECK_UART_WAKE_ENABLE (0u != WiFiSpi_UART_WAKE_ENABLE)

#endif /* End (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */

/* Bootloader communication interface enable: NOT supported yet */
#define WiFiSpi_SPI_BTLDR_COMM_ENABLED   ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_WiFiSpi) || \
                                                    (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))

#define WiFiSpi_UART_BTLDR_COMM_ENABLED   ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_WiFiSpi) || \
                                                    (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))


/***************************************
*       Type Definitions
***************************************/

/* WiFiSpi_SPI_INIT_STRUCT */
typedef struct
{
    uint32 mode;
    uint32 submode;
    uint32 sclkMode;
    uint32 oversample;
    uint32 enableMedianFilter;
    uint32 enableLateSampling;
    uint32 enableWake;
    uint32 rxDataBits;
    uint32 txDataBits;
    uint32 bitOrder;
    uint32 transferSeperation;
    uint32 rxBufferSize;
    uint8* rxBuffer;
    uint32 txBufferSize;
    uint8* txBuffer;
    uint32 enableInterrupt;
    uint32 rxInterruptMask;
    uint32 rxTriggerLevel;
    uint32 txInterruptMask;
    uint32 txTriggerLevel;
} WiFiSpi_SPI_INIT_STRUCT;

/* WiFiSpi_UART_INIT_STRUCT */
typedef struct
{
    uint32 mode;
    uint32 direction;
    uint32 dataBits;
    uint32 parity;
    uint32 stopBits;
    uint32 oversample;
    uint32 enableIrdaLowPower;
    uint32 enableMedianFilter;
    uint32 enableRetryNack;
    uint32 enableInvertedRx;
    uint32 dropOnParityErr;
    uint32 dropOnFrameErr;
    uint32 enableWake;
    uint32 rxBufferSize;
    uint8* rxBuffer;
    uint32 txBufferSize;
    uint8* txBuffer;
    uint32 enableMultiproc;
    uint32 multiprocAcceptAddr;
    uint32 multiprocAddr;
    uint32 multiprocAddrMask;
    uint32 enableInterrupt;
    uint32 rxInterruptMask;
    uint32 rxTriggerLevel;
    uint32 txInterruptMask;
    uint32 txTriggerLevel;
} WiFiSpi_UART_INIT_STRUCT;


/***************************************
*        Function Prototypes
***************************************/

/* SPI specific functions */
#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)
    void WiFiSpi_SpiInit(const WiFiSpi_SPI_INIT_STRUCT *config);
#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */

#if(WiFiSpi_SCB_MODE_SPI_INC)
    void WiFiSpi_SpiSetActiveSlaveSelect(uint32 activeSelect);
#endif /* (WiFiSpi_SCB_MODE_SPI_INC) */

/* UART specific functions */
#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)
    void WiFiSpi_UartInit(const WiFiSpi_UART_INIT_STRUCT *config);
#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */

#if(WiFiSpi_SCB_MODE_UART_INC)
    void WiFiSpi_UartSetRxAddress(uint32 address);
    void WiFiSpi_UartSetRxAddressMask(uint32 addressMask);
#endif /* (WiFiSpi_SCB_MODE_UART_INC) */

/* UART RX direction APIs */
#if(WiFiSpi_UART_RX_DIRECTION)
    uint32 WiFiSpi_UartGetChar(void);
    uint32 WiFiSpi_UartGetByte(void);
#endif /* (WiFiSpi_UART_RX_DIRECTION) */

/* UART TX direction APIs */
#if(WiFiSpi_UART_TX_DIRECTION)
    #define WiFiSpi_UartPutChar(ch)    WiFiSpi_SpiUartWriteTxData((uint32)(ch))
    void WiFiSpi_UartPutString(const char8 string[]);
    void WiFiSpi_UartPutCRLF(uint32 txDataByte);
#endif /* (WiFiSpi_UART_TX_DIRECTION) */

/* Common APIs Rx direction */
#if(WiFiSpi_RX_DIRECTION)
    uint32 WiFiSpi_SpiUartReadRxData(void);
    uint32 WiFiSpi_SpiUartGetRxBufferSize(void);
    void   WiFiSpi_SpiUartClearRxBuffer(void);
#endif /* (WiFiSpi_RX_DIRECTION) */

/* Common APIs Tx direction */
#if(WiFiSpi_TX_DIRECTION)
    void   WiFiSpi_SpiUartWriteTxData(uint32 txDataByte);
    void   WiFiSpi_SpiUartPutArray(const uint8 wrBuf[], uint32 count);
    void   WiFiSpi_SpiUartClearTxBuffer(void);
    uint32 WiFiSpi_SpiUartGetTxBufferSize(void);
#endif /* (WiFiSpi_TX_DIRECTION) */

CY_ISR_PROTO(WiFiSpi_SPI_UART_ISR);

#if(WiFiSpi_UART_RX_WAKEUP_IRQ)
    CY_ISR_PROTO(WiFiSpi_UART_WAKEUP_ISR);
#endif /* (WiFiSpi_UART_RX_WAKEUP_IRQ) */

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (WiFiSpi_SPI_BTLDR_COMM_ENABLED)
    /* SPI Bootloader physical layer functions */
    void WiFiSpi_SpiCyBtldrCommStart(void);
    void WiFiSpi_SpiCyBtldrCommStop (void);
    void WiFiSpi_SpiCyBtldrCommReset(void);
    cystatus WiFiSpi_SpiCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus WiFiSpi_SpiCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (WiFiSpi_SPI_BTLDR_COMM_ENABLED) */

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (WiFiSpi_UART_BTLDR_COMM_ENABLED)
    /* UART Bootloader physical layer functions */
    void WiFiSpi_UartCyBtldrCommStart(void);
    void WiFiSpi_UartCyBtldrCommStop (void);
    void WiFiSpi_UartCyBtldrCommReset(void);
    cystatus WiFiSpi_UartCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus WiFiSpi_UartCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (WiFiSpi_UART_BTLDR_COMM_ENABLED) */


/***************************************
*     Buffer Access Macro Definitions
***************************************/

#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)
    /* RX direction */
    void   WiFiSpi_PutWordInRxBuffer  (uint32 idx, uint32 rxDataByte);
    uint32 WiFiSpi_GetWordFromRxBuffer(uint32 idx);

    /* TX direction */
    void   WiFiSpi_PutWordInTxBuffer  (uint32 idx, uint32 txDataByte);
    uint32 WiFiSpi_GetWordFromTxBuffer(uint32 idx);

#else

    /* RX direction */
    #if(WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST)
        #define WiFiSpi_PutWordInRxBuffer(idx, rxDataByte) \
                do{                                                 \
                    WiFiSpi_rxBufferInternal[(idx)] = ((uint8) (rxDataByte)); \
                }while(0)

        #define WiFiSpi_GetWordFromRxBuffer(idx) WiFiSpi_rxBufferInternal[(idx)]

    #endif /* (WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST) */

    /* TX direction */
    #if(WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST)
        #define WiFiSpi_PutWordInTxBuffer(idx, txDataByte) \
                    do{                                             \
                        WiFiSpi_txBufferInternal[(idx)] = ((uint8) (txDataByte)); \
                    }while(0)

        #define WiFiSpi_GetWordFromTxBuffer(idx) WiFiSpi_txBufferInternal[(idx)]

    #endif /* (WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST) */

#endif /* (WiFiSpi_TX_SW_BUFFER_ENABLE) */


/***************************************
*         SPI API Constants
***************************************/

/* SPI mode enum */
#define WiFiSpi_SPI_SLAVE  (0u)
#define WiFiSpi_SPI_MASTER (1u)

/* SPI sub mode enum */
#define WiFiSpi_SPI_MODE_MOTOROLA      (0x00u)
#define WiFiSpi_SPI_MODE_TI_COINCIDES  (0x01u)
#define WiFiSpi_SPI_MODE_TI_PRECEDES   (0x11u)
#define WiFiSpi_SPI_MODE_NATIONAL      (0x02u)
#define WiFiSpi_SPI_MODE_MASK          (0x03u)
#define WiFiSpi_SPI_MODE_TI_PRECEDES_MASK  (0x10u)

/* SPI phase and polarity mode enum */
#define WiFiSpi_SPI_SCLK_CPHA0_CPOL0   (0x00u)
#define WiFiSpi_SPI_SCLK_CPHA0_CPOL1   (0x02u)
#define WiFiSpi_SPI_SCLK_CPHA1_CPOL0   (0x01u)
#define WiFiSpi_SPI_SCLK_CPHA1_CPOL1   (0x03u)

/* SPI bits order enum */
#define WiFiSpi_BITS_ORDER_LSB_FIRST   (0u)
#define WiFiSpi_BITS_ORDER_MSB_FIRST   (1u)

/* SPI transfer separation enum */
#define WiFiSpi_SPI_TRANSFER_SEPARATED     (0u)
#define WiFiSpi_SPI_TRANSFER_CONTINUOUS    (1u)

/* "activeSS" constants for SpiSetActiveSlaveSelect() function */
#define WiFiSpi_SPIM_ACTIVE_SS0    (0x00u)
#define WiFiSpi_SPIM_ACTIVE_SS1    (0x01u)
#define WiFiSpi_SPIM_ACTIVE_SS2    (0x02u)
#define WiFiSpi_SPIM_ACTIVE_SS3    (0x03u)


/***************************************
*         UART API Constants
***************************************/

/* UART sub-modes enum */
#define WiFiSpi_UART_MODE_STD          (0u)
#define WiFiSpi_UART_MODE_SMARTCARD    (1u)
#define WiFiSpi_UART_MODE_IRDA         (2u)

/* UART direction enum */
#define WiFiSpi_UART_RX    (1u)
#define WiFiSpi_UART_TX    (2u)
#define WiFiSpi_UART_TX_RX (3u)

/* UART parity enum */
#define WiFiSpi_UART_PARITY_EVEN   (0u)
#define WiFiSpi_UART_PARITY_ODD    (1u)
#define WiFiSpi_UART_PARITY_NONE   (2u)

/* UART stop bits enum */
#define WiFiSpi_UART_STOP_BITS_1   (1u)
#define WiFiSpi_UART_STOP_BITS_1_5 (2u)
#define WiFiSpi_UART_STOP_BITS_2   (3u)

/* UART IrDA low power OVS enum */
#define WiFiSpi_UART_IRDA_LP_OVS16     (16u)
#define WiFiSpi_UART_IRDA_LP_OVS32     (32u)
#define WiFiSpi_UART_IRDA_LP_OVS48     (48u)
#define WiFiSpi_UART_IRDA_LP_OVS96     (96u)
#define WiFiSpi_UART_IRDA_LP_OVS192    (192u)
#define WiFiSpi_UART_IRDA_LP_OVS768    (768u)
#define WiFiSpi_UART_IRDA_LP_OVS1536   (1536u)

/* Uart MP: mark (address) and space (data) bit definitions */
#define WiFiSpi_UART_MP_MARK       (0x100u)
#define WiFiSpi_UART_MP_SPACE      (0x000u)


/***************************************
*     Vars with External Linkage
***************************************/

#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)
    extern const WiFiSpi_SPI_INIT_STRUCT  WiFiSpi_configSpi;
    extern const WiFiSpi_UART_INIT_STRUCT WiFiSpi_configUart;
#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*    Specific SPI Macro Definitions
***************************************/

#define WiFiSpi_GET_SPI_INTR_SLAVE_MASK(sourceMask)  ((sourceMask) & WiFiSpi_INTR_SLAVE_SPI_BUS_ERROR)
#define WiFiSpi_GET_SPI_INTR_MASTER_MASK(sourceMask) ((sourceMask) & WiFiSpi_INTR_MASTER_SPI_DONE)
#define WiFiSpi_GET_SPI_INTR_RX_MASK(sourceMask) \
                                             ((sourceMask) & (uint32) ~WiFiSpi_INTR_SLAVE_SPI_BUS_ERROR)

#define WiFiSpi_GET_SPI_INTR_TX_MASK(sourceMask) \
                                             ((sourceMask) & (uint32) ~WiFiSpi_INTR_MASTER_SPI_DONE)


/***************************************
*    Specific UART Macro Definitions
***************************************/

#define WiFiSpi_UART_GET_CTRL_OVS_IRDA_LP(oversample) \
        ((WiFiSpi_UART_IRDA_LP_OVS16   == (oversample)) ? WiFiSpi_CTRL_OVS_IRDA_LP_OVS16 : \
         ((WiFiSpi_UART_IRDA_LP_OVS32   == (oversample)) ? WiFiSpi_CTRL_OVS_IRDA_LP_OVS32 : \
          ((WiFiSpi_UART_IRDA_LP_OVS48   == (oversample)) ? WiFiSpi_CTRL_OVS_IRDA_LP_OVS48 : \
           ((WiFiSpi_UART_IRDA_LP_OVS96   == (oversample)) ? WiFiSpi_CTRL_OVS_IRDA_LP_OVS96 : \
            ((WiFiSpi_UART_IRDA_LP_OVS192  == (oversample)) ? WiFiSpi_CTRL_OVS_IRDA_LP_OVS192 : \
             ((WiFiSpi_UART_IRDA_LP_OVS768  == (oversample)) ? WiFiSpi_CTRL_OVS_IRDA_LP_OVS768 : \
              ((WiFiSpi_UART_IRDA_LP_OVS1536 == (oversample)) ? WiFiSpi_CTRL_OVS_IRDA_LP_OVS1536 : \
                                                                          WiFiSpi_CTRL_OVS_IRDA_LP_OVS16)))))))

#define WiFiSpi_GET_UART_RX_CTRL_ENABLED(direction) ((0u != (WiFiSpi_UART_RX & (direction))) ? \
                                                                    (WiFiSpi_RX_CTRL_ENABLED) : (0u))

#define WiFiSpi_GET_UART_TX_CTRL_ENABLED(direction) ((0u != (WiFiSpi_UART_TX & (direction))) ? \
                                                                    (WiFiSpi_TX_CTRL_ENABLED) : (0u))


/***************************************
*        SPI Register Settings
***************************************/

#define WiFiSpi_CTRL_SPI      (WiFiSpi_CTRL_MODE_SPI)
#define WiFiSpi_SPI_RX_CTRL   (WiFiSpi_RX_CTRL_ENABLED)
#define WiFiSpi_SPI_TX_CTRL   (WiFiSpi_TX_CTRL_ENABLED)


/***************************************
*       SPI Init Register Settings
***************************************/

#if(WiFiSpi_SCB_MODE_SPI_CONST_CFG)

    /* SPI Configuration */
    #define WiFiSpi_SPI_DEFAULT_CTRL \
                    (WiFiSpi_GET_CTRL_OVS(WiFiSpi_SPI_OVS_FACTOR)         | \
                     WiFiSpi_GET_CTRL_EC_AM_MODE(WiFiSpi_SPI_WAKE_ENABLE) | \
                     WiFiSpi_CTRL_SPI)

    #define WiFiSpi_SPI_DEFAULT_SPI_CTRL \
                    (WiFiSpi_GET_SPI_CTRL_CONTINUOUS    (WiFiSpi_SPI_TRANSFER_SEPARATION)       | \
                     WiFiSpi_GET_SPI_CTRL_SELECT_PRECEDE(WiFiSpi_SPI_SUB_MODE &                   \
                                                                  WiFiSpi_SPI_MODE_TI_PRECEDES_MASK)     | \
                     WiFiSpi_GET_SPI_CTRL_SCLK_MODE     (WiFiSpi_SPI_CLOCK_MODE)                | \
                     WiFiSpi_GET_SPI_CTRL_LATE_MISO_SAMPLE(WiFiSpi_SPI_LATE_MISO_SAMPLE_ENABLE) | \
                     WiFiSpi_GET_SPI_CTRL_SUB_MODE      (WiFiSpi_SPI_SUB_MODE)                  | \
                     WiFiSpi_GET_SPI_CTRL_MASTER_MODE   (WiFiSpi_SPI_MODE))

    /* RX direction */
    #define WiFiSpi_SPI_DEFAULT_RX_CTRL \
                    (WiFiSpi_GET_RX_CTRL_DATA_WIDTH(WiFiSpi_SPI_RX_DATA_BITS_NUM)     | \
                     WiFiSpi_GET_RX_CTRL_BIT_ORDER (WiFiSpi_SPI_BITS_ORDER)           | \
                     WiFiSpi_GET_RX_CTRL_MEDIAN    (WiFiSpi_SPI_MEDIAN_FILTER_ENABLE) | \
                     WiFiSpi_SPI_RX_CTRL)

    #define WiFiSpi_SPI_DEFAULT_RX_FIFO_CTRL \
                    WiFiSpi_GET_RX_FIFO_CTRL_TRIGGER_LEVEL(WiFiSpi_SPI_RX_TRIGGER_LEVEL)

    /* TX direction */
    #define WiFiSpi_SPI_DEFAULT_TX_CTRL \
                    (WiFiSpi_GET_TX_CTRL_DATA_WIDTH(WiFiSpi_SPI_TX_DATA_BITS_NUM) | \
                     WiFiSpi_GET_TX_CTRL_BIT_ORDER (WiFiSpi_SPI_BITS_ORDER)       | \
                     WiFiSpi_SPI_TX_CTRL)

    #define WiFiSpi_SPI_DEFAULT_TX_FIFO_CTRL \
                    WiFiSpi_GET_TX_FIFO_CTRL_TRIGGER_LEVEL(WiFiSpi_SPI_TX_TRIGGER_LEVEL)

    /* Interrupt sources */
    #define WiFiSpi_SPI_INTERRUPT_DISABLE          (0u == WiFiSpi_SPI_INTERRUPT_ENABLE)

    #define WiFiSpi_SPI_DEFAULT_INTR_SPI_EC_MASK   (WiFiSpi_NO_INTR_SOURCES)

    #define WiFiSpi_SPI_DEFAULT_INTR_I2C_EC_MASK   (WiFiSpi_NO_INTR_SOURCES)
    #define WiFiSpi_SPI_DEFAULT_INTR_SLAVE_MASK \
                    (WiFiSpi_SPI_INTR_RX_MASK & WiFiSpi_INTR_SLAVE_SPI_BUS_ERROR)

    #define WiFiSpi_SPI_DEFAULT_INTR_MASTER_MASK \
                    (WiFiSpi_SPI_INTR_TX_MASK & WiFiSpi_INTR_MASTER_SPI_DONE)

    #define WiFiSpi_SPI_DEFAULT_INTR_RX_MASK \
                    (WiFiSpi_SPI_INTR_RX_MASK & (uint32) ~WiFiSpi_INTR_SLAVE_SPI_BUS_ERROR)

    #define WiFiSpi_SPI_DEFAULT_INTR_TX_MASK \
                    (WiFiSpi_SPI_INTR_TX_MASK & (uint32) ~WiFiSpi_INTR_MASTER_SPI_DONE)

#endif /* (WiFiSpi_SCB_MODE_SPI_CONST_CFG) */


/***************************************
*        UART Register Settings
***************************************/

#define WiFiSpi_CTRL_UART      (WiFiSpi_CTRL_MODE_UART)
#define WiFiSpi_UART_RX_CTRL   (WiFiSpi_RX_CTRL_LSB_FIRST) /* LSB for UART goes first */
#define WiFiSpi_UART_TX_CTRL   (WiFiSpi_TX_CTRL_LSB_FIRST) /* LSB for UART goes first */


/***************************************
*      UART Init Register Settings
***************************************/

#if(WiFiSpi_SCB_MODE_UART_CONST_CFG)

    /* UART configuration */
    #if(WiFiSpi_UART_MODE_IRDA == WiFiSpi_UART_SUB_MODE)

        #define WiFiSpi_DEFAULT_CTRL_OVS   ((0u != WiFiSpi_UART_IRDA_LOW_POWER) ?              \
                                (WiFiSpi_UART_GET_CTRL_OVS_IRDA_LP(WiFiSpi_UART_OVS_FACTOR)) : \
                                (WiFiSpi_CTRL_OVS_IRDA_OVS16))

    #else

        #define WiFiSpi_DEFAULT_CTRL_OVS   WiFiSpi_GET_CTRL_OVS(WiFiSpi_UART_OVS_FACTOR)

    #endif /* (WiFiSpi_UART_MODE_IRDA == WiFiSpi_UART_SUB_MODE) */

    #define WiFiSpi_UART_DEFAULT_CTRL \
                                (WiFiSpi_GET_CTRL_ADDR_ACCEPT(WiFiSpi_UART_MP_ACCEPT_ADDRESS) | \
                                 WiFiSpi_DEFAULT_CTRL_OVS                                              | \
                                 WiFiSpi_CTRL_UART)

    #define WiFiSpi_UART_DEFAULT_UART_CTRL \
                                    (WiFiSpi_GET_UART_CTRL_MODE(WiFiSpi_UART_SUB_MODE))

    /* RX direction */
    #define WiFiSpi_UART_DEFAULT_RX_CTRL_PARITY \
                                ((WiFiSpi_UART_PARITY_NONE != WiFiSpi_UART_PARITY_TYPE) ?      \
                                  (WiFiSpi_GET_UART_RX_CTRL_PARITY(WiFiSpi_UART_PARITY_TYPE) | \
                                   WiFiSpi_UART_RX_CTRL_PARITY_ENABLED) : (0u))

    #define WiFiSpi_UART_DEFAULT_UART_RX_CTRL \
                    (WiFiSpi_GET_UART_RX_CTRL_MODE(WiFiSpi_UART_STOP_BITS_NUM)                    | \
                     WiFiSpi_GET_UART_RX_CTRL_POLARITY(WiFiSpi_UART_IRDA_POLARITY)                | \
                     WiFiSpi_GET_UART_RX_CTRL_MP_MODE(WiFiSpi_UART_MP_MODE_ENABLE)                | \
                     WiFiSpi_GET_UART_RX_CTRL_DROP_ON_PARITY_ERR(WiFiSpi_UART_DROP_ON_PARITY_ERR) | \
                     WiFiSpi_GET_UART_RX_CTRL_DROP_ON_FRAME_ERR(WiFiSpi_UART_DROP_ON_FRAME_ERR)   | \
                     WiFiSpi_UART_DEFAULT_RX_CTRL_PARITY)

    #define WiFiSpi_UART_DEFAULT_RX_CTRL \
                                (WiFiSpi_GET_RX_CTRL_DATA_WIDTH(WiFiSpi_UART_DATA_BITS_NUM)        | \
                                 WiFiSpi_GET_RX_CTRL_MEDIAN    (WiFiSpi_UART_MEDIAN_FILTER_ENABLE) | \
                                 WiFiSpi_GET_UART_RX_CTRL_ENABLED(WiFiSpi_UART_DIRECTION))

    #define WiFiSpi_UART_DEFAULT_RX_FIFO_CTRL \
                                WiFiSpi_GET_RX_FIFO_CTRL_TRIGGER_LEVEL(WiFiSpi_UART_RX_TRIGGER_LEVEL)

    #define WiFiSpi_UART_DEFAULT_RX_MATCH_REG  ((0u != WiFiSpi_UART_MP_MODE_ENABLE) ?          \
                                (WiFiSpi_GET_RX_MATCH_ADDR(WiFiSpi_UART_MP_RX_ADDRESS) | \
                                 WiFiSpi_GET_RX_MATCH_MASK(WiFiSpi_UART_MP_RX_ADDRESS_MASK)) : (0u))

    /* TX direction */
    #define WiFiSpi_UART_DEFAULT_TX_CTRL_PARITY (WiFiSpi_UART_DEFAULT_RX_CTRL_PARITY)

    #define WiFiSpi_UART_DEFAULT_UART_TX_CTRL \
                                (WiFiSpi_GET_UART_TX_CTRL_MODE(WiFiSpi_UART_STOP_BITS_NUM)       | \
                                 WiFiSpi_GET_UART_TX_CTRL_RETRY_NACK(WiFiSpi_UART_RETRY_ON_NACK) | \
                                 WiFiSpi_UART_DEFAULT_TX_CTRL_PARITY)

    #define WiFiSpi_UART_DEFAULT_TX_CTRL \
                                (WiFiSpi_GET_TX_CTRL_DATA_WIDTH(WiFiSpi_UART_DATA_BITS_NUM) | \
                                 WiFiSpi_GET_UART_TX_CTRL_ENABLED(WiFiSpi_UART_DIRECTION))

    #define WiFiSpi_UART_DEFAULT_TX_FIFO_CTRL \
                                WiFiSpi_GET_TX_FIFO_CTRL_TRIGGER_LEVEL(WiFiSpi_UART_TX_TRIGGER_LEVEL)

    /* Interrupt sources */
    #define WiFiSpi_UART_INTERRUPT_DISABLE         (0u == WiFiSpi_UART_INTERRUPT_ENABLE)
    #define WiFiSpi_UART_DEFAULT_INTR_I2C_EC_MASK  (WiFiSpi_NO_INTR_SOURCES)
    #define WiFiSpi_UART_DEFAULT_INTR_SPI_EC_MASK  (WiFiSpi_NO_INTR_SOURCES)
    #define WiFiSpi_UART_DEFAULT_INTR_SLAVE_MASK   (WiFiSpi_NO_INTR_SOURCES)
    #define WiFiSpi_UART_DEFAULT_INTR_MASTER_MASK  (WiFiSpi_NO_INTR_SOURCES)
    #define WiFiSpi_UART_DEFAULT_INTR_RX_MASK      (WiFiSpi_UART_INTR_RX_MASK)
    #define WiFiSpi_UART_DEFAULT_INTR_TX_MASK      (WiFiSpi_UART_INTR_TX_MASK)

#endif /* (WiFiSpi_SCB_MODE_UART_CONST_CFG) */

#endif /* CY_SCB_SPI_UART_WiFiSpi_H */


/* [] END OF FILE */
