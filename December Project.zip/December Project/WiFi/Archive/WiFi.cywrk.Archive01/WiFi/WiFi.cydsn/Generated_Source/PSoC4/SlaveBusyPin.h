/*******************************************************************************
* File Name: SlaveBusyPin.h  
* Version 1.90
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SlaveBusyPin_H) /* Pins SlaveBusyPin_H */
#define CY_PINS_SlaveBusyPin_H

#include "cytypes.h"
#include "cyfitter.h"
#include "SlaveBusyPin_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    SlaveBusyPin_Write(uint8 value) ;
void    SlaveBusyPin_SetDriveMode(uint8 mode) ;
uint8   SlaveBusyPin_ReadDataReg(void) ;
uint8   SlaveBusyPin_Read(void) ;
uint8   SlaveBusyPin_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define SlaveBusyPin_DRIVE_MODE_BITS        (3)
#define SlaveBusyPin_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - SlaveBusyPin_DRIVE_MODE_BITS))
#define SlaveBusyPin_DRIVE_MODE_SHIFT       (0x00u)
#define SlaveBusyPin_DRIVE_MODE_MASK        (0x07u << SlaveBusyPin_DRIVE_MODE_SHIFT)

#define SlaveBusyPin_DM_ALG_HIZ         (0x00u << SlaveBusyPin_DRIVE_MODE_SHIFT)
#define SlaveBusyPin_DM_DIG_HIZ         (0x01u << SlaveBusyPin_DRIVE_MODE_SHIFT)
#define SlaveBusyPin_DM_RES_UP          (0x02u << SlaveBusyPin_DRIVE_MODE_SHIFT)
#define SlaveBusyPin_DM_RES_DWN         (0x03u << SlaveBusyPin_DRIVE_MODE_SHIFT)
#define SlaveBusyPin_DM_OD_LO           (0x04u << SlaveBusyPin_DRIVE_MODE_SHIFT)
#define SlaveBusyPin_DM_OD_HI           (0x05u << SlaveBusyPin_DRIVE_MODE_SHIFT)
#define SlaveBusyPin_DM_STRONG          (0x06u << SlaveBusyPin_DRIVE_MODE_SHIFT)
#define SlaveBusyPin_DM_RES_UPDWN       (0x07u << SlaveBusyPin_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define SlaveBusyPin_MASK               SlaveBusyPin__MASK
#define SlaveBusyPin_SHIFT              SlaveBusyPin__SHIFT
#define SlaveBusyPin_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define SlaveBusyPin_PS                     (* (reg32 *) SlaveBusyPin__PS)
/* Port Configuration */
#define SlaveBusyPin_PC                     (* (reg32 *) SlaveBusyPin__PC)
/* Data Register */
#define SlaveBusyPin_DR                     (* (reg32 *) SlaveBusyPin__DR)
/* Input Buffer Disable Override */
#define SlaveBusyPin_INP_DIS                (* (reg32 *) SlaveBusyPin__PC2)


#if defined(SlaveBusyPin__INTSTAT)  /* Interrupt Registers */

    #define SlaveBusyPin_INTSTAT                (* (reg32 *) SlaveBusyPin__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins SlaveBusyPin_H */


/* [] END OF FILE */
