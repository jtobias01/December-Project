/*******************************************************************************
* File Name: WiFiSpi_SPI_UART.c
* Version 1.0
*
* Description:
*  This file provides the source code to the API for the SCB Component in
*  SPI and UART modes.
*
* Note:
*
*******************************************************************************
* Copyright 2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "WiFiSpi_SPI_UART_PVT.h"


/***************************************
*        SPI/UART Private Vars
***************************************/

#if(WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST)
    volatile uint32 WiFiSpi_rxBufferHead;
    volatile uint32 WiFiSpi_rxBufferTail;
    volatile uint8  WiFiSpi_rxBufferOverflow;
#endif /* (WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST) */

#if(WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST)
    volatile uint32 WiFiSpi_txBufferHead;
    volatile uint32 WiFiSpi_txBufferTail;
#endif /* (WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST) */

#if(WiFiSpi_INTERNAL_RX_SW_BUFFER)
    /* Add one element to the buffer to receive full packet. One byte in receive buffer is always empty */
    volatile uint8 WiFiSpi_rxBufferInternal[WiFiSpi_RX_BUFFER_SIZE];
#endif /* (WiFiSpi_INTERNAL_RX_SW_BUFFER) */

#if(WiFiSpi_INTERNAL_TX_SW_BUFFER)
    volatile uint8 WiFiSpi_txBufferInternal[WiFiSpi_TX_BUFFER_SIZE];
#endif /* (WiFiSpi_INTERNAL_TX_SW_BUFFER) */


#if(WiFiSpi_RX_DIRECTION)

    /*******************************************************************************
    * Function Name: WiFiSpi_SpiUartReadRxData
    ********************************************************************************
    *
    * Summary:
    *  Retrieves the next data element from the receive buffer. Undefined data will
    *  be returned if the RX buffer is empty.
    *  Call WiFiSpi_SpiUartGetRxBufferSize() to return buffer size.
    *   - RX software buffer disabled: Returns data element retrieved from RX FIFO.
    *   - RX software buffer enabled: Returns data element from the software
    *     receive buffer.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  Next data element from the receive buffer.
    *
    * Global Variables:
    *  Look into WiFiSpi_SpiInit for description.
    *
    *******************************************************************************/
    uint32 WiFiSpi_SpiUartReadRxData(void)
    {
        uint32 rxData = 0u;
        
        #if(WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST)
            uint32 locTail;
        #endif /* (WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST) */

        #if(WiFiSpi_CHECK_RX_SW_BUFFER)
        {
            if(WiFiSpi_rxBufferHead != WiFiSpi_rxBufferTail)
            {
                /* There is data in RX software buffer */

                /* Calculate index to read from */
                locTail = (WiFiSpi_rxBufferTail + 1u);

                if(WiFiSpi_RX_BUFFER_SIZE == locTail)
                {
                    locTail = 0u;
                }

                /* Get data fron RX software buffer */
                rxData = WiFiSpi_GetWordFromRxBuffer(locTail);

                /* Change index in the buffer */
                WiFiSpi_rxBufferTail = locTail;
            }
        }
        #else
        {
            rxData = WiFiSpi_RX_FIFO_RD_REG; /* Read data from RX FIFO */
        }
        #endif

        return(rxData);
    }


    /*******************************************************************************
    * Function Name: WiFiSpi_SpiUartGetRxBufferSize
    ********************************************************************************
    *
    * Summary:
    *  Returns the number of received data elements in the receive buffer.
    *   - RX software buffer disabled: returns the number of used entries in
    *     RX FIFO.
    *   - RX software buffer enabled: returns the number of elements which were
    *     placed in receive buffer.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  Number of received data elements
    *
    *******************************************************************************/
    uint32 WiFiSpi_SpiUartGetRxBufferSize(void)
    {
        uint32 size;
        #if(WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST)
            uint32 locHead;
        #endif /* (WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST) */

        #if(WiFiSpi_CHECK_RX_SW_BUFFER)
        {
            locHead = WiFiSpi_rxBufferHead;

            if(locHead >= WiFiSpi_rxBufferTail)
            {
                size = (locHead - WiFiSpi_rxBufferTail);
            }
            else
            {
                size = (locHead + (WiFiSpi_RX_BUFFER_SIZE - WiFiSpi_rxBufferTail));
            }
        }
        #else
        {
            size = WiFiSpi_GET_RX_FIFO_ENTRIES;
        }
        #endif

        return(size);
    }


    /*******************************************************************************
    * Function Name: WiFiSpi_SpiUartClearRxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Clear the receive buffer and RX FIFO.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void WiFiSpi_SpiUartClearRxBuffer(void)
    {
        #if(WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST)
            uint32 intSourceMask;
        #endif /* (WiFiSpi_INTERNAL_RX_SW_BUFFER_CONST) */

        #if(WiFiSpi_CHECK_RX_SW_BUFFER)
        {
            intSourceMask = WiFiSpi_SpiUartDisableIntRx();

            WiFiSpi_CLEAR_RX_FIFO;

            /* Flush RX software buffer */
            WiFiSpi_rxBufferHead     = WiFiSpi_rxBufferTail;
            WiFiSpi_rxBufferOverflow = 0u;

            /* End RX transfer */
            WiFiSpi_ClearRxInterruptSource(WiFiSpi_INTR_RX_ALL);

            WiFiSpi_SpiUartEnableIntRx(intSourceMask);
        }
        #else
        {
            WiFiSpi_CLEAR_RX_FIFO;
        }
        #endif
    }

#endif /* (WiFiSpi_RX_DIRECTION) */


#if(WiFiSpi_TX_DIRECTION)

    /*******************************************************************************
    * Function Name: WiFiSpi_SpiUartWriteTxData
    ********************************************************************************
    *
    * Summary:
    *  Places a data entry into the transmit buffer to be sent at the next available
    *  bus time.
    *  This function is blocking and waits until there is space available to put the
    *  requested data in the transmit buffer.
    *
    * Parameters:
    *  txDataByte: the data to be transmitted.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void WiFiSpi_SpiUartWriteTxData(uint32 txDataByte)
    {
        #if(WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST)
            uint32 locHead;
            uint32 intSourceMask;
        #endif /* (WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST) */

        #if(WiFiSpi_CHECK_TX_SW_BUFFER)
        {
            /* Head index to put data */
            locHead = (WiFiSpi_txBufferHead + 1u);

            /* Adjust TX software buffer index */
            if(WiFiSpi_TX_BUFFER_SIZE == locHead)
            {
                locHead = 0u;
            }

            while(locHead == WiFiSpi_txBufferTail)
            {
                /* Wait for space in the TX software buffer */
            }

            /* The TX software buffer has at least one room */

            if((WiFiSpi_txBufferHead == WiFiSpi_txBufferTail) &&
               (WiFiSpi_FIFO_SIZE != WiFiSpi_GET_TX_FIFO_ENTRIES))
            {
                /* TX software buffer is empty: put data directly in TX FIFO */
                WiFiSpi_TX_FIFO_WR_REG = txDataByte;
            }
            /* Put data in the TX software buffer */
            else
            {
                /* Clear old status of INTR_TX_EMPTY. It sets at the end of transfer: TX FIFO empty. */
                WiFiSpi_ClearTxInterruptSource(WiFiSpi_INTR_TX_EMPTY);

                WiFiSpi_PutWordInTxBuffer(locHead, txDataByte);

                WiFiSpi_txBufferHead = locHead;

                /* Enable interrupt to transmit */
                intSourceMask  = WiFiSpi_INTR_TX_EMPTY;
                intSourceMask |= WiFiSpi_GetTxInterruptMode();
                WiFiSpi_SpiUartEnableIntTx(intSourceMask);
            }
        }
        #else
        {
            while(WiFiSpi_FIFO_SIZE == WiFiSpi_GET_TX_FIFO_ENTRIES)
            {
                /* Block while TX FIFO is FULL */
            }

            WiFiSpi_TX_FIFO_WR_REG = txDataByte;
        }
        #endif
    }


    /*******************************************************************************
    * Function Name: WiFiSpi_SpiUartPutArray
    ********************************************************************************
    *
    * Summary:
    *  Places an array of data into the transmit buffer to be sent.
    *  This function is blocking and waits until there is a space available to put
    *  all the requested data in the transmit buffer. The array size can be greater
    *  than transmit buffer size.
    *
    * Parameters:
    *  wrBuf:  pointer to an array with data to be placed in transmit buffer.
    *  count:  number of data elements to be placed in the transmit buffer.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void WiFiSpi_SpiUartPutArray(const uint8 wrBuf[], uint32 count)
    {
        uint32 i;

        for(i=0u; i < count; i++)
        {
            WiFiSpi_SpiUartWriteTxData((uint32) wrBuf[i]);
        }
    }


    /*******************************************************************************
    * Function Name: WiFiSpi_SpiUartGetTxBufferSize
    ********************************************************************************
    *
    * Summary:
    *  Returns the number of elements currently in the transmit buffer.
    *  TX software buffer disabled: returns the number of used entries in TX FIFO.
    *  TX software buffer enabled: returns the number of elements currently used
    *  in the transmit buffer. This number does not include used entries in the
    *  TX FIFO. The transmit buffer size is zero until the TX FIFO is full.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  Number of data elements ready to transmit.
    *
    *******************************************************************************/
    uint32 WiFiSpi_SpiUartGetTxBufferSize(void)
    {
        uint32 size;
        #if(WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST)
            uint32 locTail;
        #endif /* (WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST) */

        #if(WiFiSpi_CHECK_TX_SW_BUFFER)
        {
            /* Get current Tail index */
            locTail = WiFiSpi_txBufferTail;

            if(WiFiSpi_txBufferHead >= locTail)
            {
                size = (WiFiSpi_txBufferHead - locTail);
            }
            else
            {
                size = (WiFiSpi_txBufferHead + (WiFiSpi_TX_BUFFER_SIZE - locTail));
            }
        }
        #else
        {
            size = WiFiSpi_GET_TX_FIFO_ENTRIES;
        }
        #endif

        return(size);
    }


    /*******************************************************************************
    * Function Name: WiFiSpi_SpiUartClearTxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Clears the transmit buffer and TX FIFO.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void WiFiSpi_SpiUartClearTxBuffer(void)
    {
        #if(WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST)
            uint32 intSourceMask;
        #endif /* (WiFiSpi_INTERNAL_TX_SW_BUFFER_CONST) */

        #if(WiFiSpi_CHECK_TX_SW_BUFFER)
        {
            intSourceMask = WiFiSpi_SpiUartDisableIntTx();

            WiFiSpi_CLEAR_TX_FIFO;

            /* Flush TX software buffer */
            WiFiSpi_txBufferHead = WiFiSpi_txBufferTail;

            /* End TX transfer if it is in progress */
            intSourceMask &= (uint32) ~WiFiSpi_INTR_TX_EMPTY;

            WiFiSpi_SpiUartEnableIntTx(intSourceMask);
        }
        #else
        {
            WiFiSpi_CLEAR_TX_FIFO;
        }
        #endif
    }

#endif /* (WiFiSpi_TX_DIRECTION) */


/*******************************************************************************
* Function Name: WiFiSpi_SpiUartDisableIntRx
********************************************************************************
*
* Summary:
*  Disables RX interrupt sources.
*
* Parameters:
*  None
*
* Return:
*  Returns RX interrupt soureces enabled before function call.
*
*******************************************************************************/
uint32 WiFiSpi_SpiUartDisableIntRx(void)
{
    uint32 intSource;

    intSource = WiFiSpi_GetRxInterruptMode();

    WiFiSpi_SetRxInterruptMode(WiFiSpi_NO_INTR_SOURCES);

    return(intSource);
}


/*******************************************************************************
* Function Name: WiFiSpi_SpiUartDisableIntTx
********************************************************************************
*
* Summary:
*  Disables TX interrupt sources.
*
* Parameters:
*  None
*
* Return:
*  Returns TX interrupt soureces enabled before function call.
*
*******************************************************************************/
uint32 WiFiSpi_SpiUartDisableIntTx(void)
{
    uint32 intSourceMask;

    intSourceMask = WiFiSpi_GetTxInterruptMode();

    WiFiSpi_SetTxInterruptMode(WiFiSpi_NO_INTR_SOURCES);

    return(intSourceMask);
}


#if(WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG)

    /*******************************************************************************
    * Function Name: WiFiSpi_PutWordInRxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Stores byte/word into the RX buffer.
    *  Only available in Unconfigured operation mode.
    *
    * Parameters:
    *  index:      index to store data byte/word in the RX buffer.
    *  rxDataByte: byte/word to store.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void WiFiSpi_PutWordInRxBuffer(uint32 idx, uint32 rxDataByte)
    {
        /* Put data in the buffer */
        if(WiFiSpi_ONE_BYTE_WIDTH == WiFiSpi_rxDataBits)
        {
            WiFiSpi_rxBuffer[idx] = ((uint8) rxDataByte);
        }
        else
        {
            WiFiSpi_rxBuffer[(uint32)(idx << 1u)]      = LO8(LO16(rxDataByte));
            WiFiSpi_rxBuffer[(uint32)(idx << 1u) + 1u] = HI8(LO16(rxDataByte));
        }
    }


    /*******************************************************************************
    * Function Name: WiFiSpi_GetWordFromRxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Reads byte/word from RX buffer.
    *  Only available in Unconfigured operation mode.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  Returns byte/word read from RX buffer.
    *
    *******************************************************************************/
    uint32 WiFiSpi_GetWordFromRxBuffer(uint32 idx)
    {
        uint32 value;

        if(WiFiSpi_ONE_BYTE_WIDTH == WiFiSpi_rxDataBits)
        {
            value = WiFiSpi_rxBuffer[idx];
        }
        else
        {
            value  = (uint32) WiFiSpi_rxBuffer[(uint32)(idx << 1u)];
            value |= (uint32) ((uint32)WiFiSpi_rxBuffer[(uint32)(idx << 1u) + 1u] << 8u);
        }

        return(value);
    }


    /*******************************************************************************
    * Function Name: WiFiSpi_PutWordInTxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Stores byte/word into the TX buffer.
    * Only available in Unconfigured operation mode.
    *
    * Parameters:
    *  idx:        index to store data byte/word in the TX buffer.
    *  txDataByte: byte/word to store.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void WiFiSpi_PutWordInTxBuffer(uint32 idx, uint32 txDataByte)
    {
        /* Put data in the buffer */
        if(WiFiSpi_ONE_BYTE_WIDTH == WiFiSpi_txDataBits)
        {
            WiFiSpi_txBuffer[idx] = ((uint8) txDataByte);
        }
        else
        {
            WiFiSpi_txBuffer[(uint32)(idx << 1u)]      = LO8(LO16(txDataByte));
            WiFiSpi_txBuffer[(uint32)(idx << 1u) + 1u] = HI8(LO16(txDataByte));
        }
    }


    /*******************************************************************************
    * Function Name: WiFiSpi_GetWordFromTxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Reads byte/word from TX buffer.
    *  Only available in Unconfigured operation mode.
    *
    * Parameters:
    *  idx: index to get data byte/word from the TX buffer.
    *
    * Return:
    *  Returns byte/word read from TX buffer.
    *
    *******************************************************************************/
    uint32 WiFiSpi_GetWordFromTxBuffer(uint32 idx)
    {
        uint32 value;

        if(WiFiSpi_ONE_BYTE_WIDTH == WiFiSpi_txDataBits)
        {
            value = (uint32) WiFiSpi_txBuffer[idx];
        }
        else
        {
            value  = (uint32) WiFiSpi_txBuffer[(uint32)(idx << 1u)];
            value |= (uint32) ((uint32) WiFiSpi_txBuffer[(uint32)(idx << 1u) + 1u] << 8u);
        }

        return(value);
    }

#endif /* (WiFiSpi_SCB_MODE_UNCONFIG_CONST_CFG) */


/* [] END OF FILE */
