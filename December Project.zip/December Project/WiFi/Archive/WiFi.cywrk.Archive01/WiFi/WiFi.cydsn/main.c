/* ========================================
 *
 The following firmware was developed by Cypress Semiconductor
This work is licensed under a Creative Commons Attribution 3.0 Unported License.
http://creativecommons.org/licenses/by/3.0/deed.en_US
You are free to:
-To Share — to copy, distribute and transmit the work 
-To Remix — to adapt the work 
-To make commercial use of the work

Some of the source comes from:
http://www.coocox.org/driver_comp/wifi_shield-c675.html?mc=9&sc=65
* ========================================
*/

#include <device.h>
#include <WiFiClient.h>
#include <WiFi.h>
#include <server_drv.h>
#include <html.h>

#define SOCKET 0
#define HTTP_PORT 80
#define LED1_CHAR 'r'
#define LED2_CHAR 'b'
#define LED3_CHAR 'g'
#define NULL_CHAR '\0'
#define NEWLINE   '\n'
#define LINEFEED  '\r'
#define LED1_NAME "Red"
#define LED2_NAME "Blue"
#define LED3_NAME "Green"
#define LED1_READ PWM_1_ReadCompare1
#define LED2_READ PWM_1_ReadCompare2
#define LED3_READ PWM_2_ReadCompare
#define LED1_WRITE PWM_1_WriteCompare1
#define LED2_WRITE PWM_1_WriteCompare2
#define LED3_WRITE PWM_2_WriteCompare
#define GET_BUFFER_SIZE 50

#define RESTART_VAL 50

// Keeps the server up and running
uint8 ServerAv(void);

// Used to parse the request
// returns 1 on a valid get request
uint8 ParseData(char *getData);
// Helper function for parsing the request
// Returns 0-99 or 255 if the request is invalid
uint8 ReadUint8Val(char **getData, char delim, char field, uint8 def);


// Creates the table row and the form data for the specified field
void SendFormData(char * name, char field, uint8 val);
// Helper function, takes value and writes ascii to the spi interface
// takes 0-99 only.
void WriteUint8Val(uint8 val);

void main()
{
    char getData[GET_BUFFER_SIZE];
    uint8 localIP[] = {255,255,255,255};
    PWM_1_Start();
    PWM_2_Start();
    
    // Give the WiFi chip a chance to init
    CyDelay(1000);
    WiFi_Init();
    
    // SSID and Password
    WiFi_Begin(WPA, "PSoC4", "PSoC4WAP");
    
    // Give time to connect
    do{
        CyDelay(100);
        
        // Grab the IP Address, look in the debugger if needed
        WiFi_LocalIPGet((uint8_t*)(&localIP));
        
        // This IP is assigned by DHCP on my router, turn on the L9 LED to indicate we're ready
        if(localIP[0] == 192 && localIP[1] == 168 && localIP[2] == 1 && localIP[3] == 10)
            WiFiLED_Write(1);
            
    } while(localIP[0] == 0);
    ServerDrv_StartServer(HTTP_PORT, SOCKET);
    
    while(1)
    {
        if(ServerAv())
        {
            // used to save the previous charcter to check for \n\n
            uint8 lastVal = 0;
            
            // used to keep our position in the request array
            uint8 pos;
            
            // Clear out old data
            for(pos = GET_BUFFER_SIZE; pos>0;)
            {
                getData[--pos]=NULL_CHAR;
            }
            
            while(WiFiClient_Connected())
            {
                if(WiFiClient_Available())
                {
                    uint8 curVal = WiFiClient_ReadByte();
                    
                    // if we get two \n's indicating the client is done with the request
                    // send our response
                    if(lastVal == NEWLINE && curVal==NEWLINE)
                    {
                        // Parse the response
                        //ParseData(getData);
                        if(!ParseData(getData)){
                            // Standard HTTP Header
                            WiFiClient_WriteChunk(HTTP_HEADER);
                            // HTML header/body/form/table and sizing for mobile
                            WiFiClient_WriteChunk(HEAD BODY);
                            SendFormData(LED1_NAME, LED1_CHAR, LED1_READ());
                            SendFormData(LED2_NAME, LED2_CHAR, LED2_READ());
                            SendFormData(LED3_NAME, LED3_CHAR, LED3_READ());
                            // HTML end of table, form, body and html.  Addition two \r\n to indicate we're done
                            WiFiClient_WriteChunk(FOOTER HTTP_FOOTER);
                            
                            // Clear out our buffer, we're done processing
                            for(pos = GET_BUFFER_SIZE; pos>0;)
                            {
                                getData[--pos]=NULL_CHAR;
                            }
                        }
                        CyDelay(10);
                        // Close the connection
                        // Failure to do so will cause the browser to sit for much longer
                        WiFiClient_Stop();
                        
                    }
                    
                    // ignore LINEFEED
                    if(curVal != LINEFEED)
                    {
                        // add the first GET_BUFFER_SIZE bytes to our buffer for GET processing
                        if(pos < GET_BUFFER_SIZE)
                            getData[pos++]=curVal;
                        lastVal=curVal;
                    }
                }
            }
            WiFiClient_Stop();
        }
    }
}

// Starts up the server, checks that it continues to run
uint8 ServerAv()
{
    static uint8 restartCnt = 0;
    if((ServerDrv_GetServerState(SOCKET) == CLOSED) && (restartCnt++>RESTART_VAL))
    {
        restartCnt = 0;
        ServerDrv_StartServer(HTTP_PORT, SOCKET);
    }
    WiFiClient_Init(SOCKET);
    if(WiFiClient_Status() == ESTABLISHED)
    {
        return 1;
    }
    return 0;
}

// format will be "GET /r?r=##&b=##&g=## "
// ## can be 0, 1 or 2 digits
uint8 ParseData(char* getData)
{
    uint8 vals[]={0,0,0};
    
    if(strncmp(getData, "GET /r?",7))
        return 0;
    getData += 6;
    vals[0] = ReadUint8Val(&getData, '?', LED1_CHAR, LED1_READ());
    if(vals[0] == 255)
        return 0;
    vals[1] = ReadUint8Val(&getData, '&', LED2_CHAR, LED2_READ());
    if(vals[1] == 255)
        return 0;
    vals[2] = ReadUint8Val(&getData, '&', LED3_CHAR, LED3_READ());
    if(vals[2] == 255)
        return 0;
    
    if(getData[0]==' '){
        // Technically the PWMs can handle up to 255, but practically speaking you can't see
        // much difference beyone 100.  As a result we go between 0-99 to keep things easy.
        LED1_WRITE(vals[0]);
        LED2_WRITE(vals[1]);
        LED3_WRITE(vals[2]);
        return 1;
    }
    return 0;
}

// Helper function, make sure the string is <delim><field>=<0, 1, or 2 ints>
// Has the side effect of incrementing pos
// returns 255 on failure
uint8 ReadUint8Val(char** getData, char delim, char field, uint8 def)
{
    // Expect at most two ASCII chars between 0-9.
    uint8 ret = def;
    if((*getData)[0]==delim && (*getData)[1]==field && (*getData)[2] == '='){
        (*getData)+=3;
        if((*getData)[0] >= '0' && (*getData)[0] <='9')
        {
            ret = 0;
            ret += (*((*getData)++) - '0');
            if((*getData)[0] >= '0' && (*getData)[0] <='9')
            {
                ret *= 10;
                ret += (*((*getData)++) - '0');
            }
        }
    }else{
        // Error, undefined format of get request
        return 0xff;
    }
    return ret;
}


// Writes a table row with the LED information
void SendFormData(char * name, char field, uint8 val)
{
    WiFiClient_WriteChunk(TR_START COL1_START);
    WiFiClient_WriteChunk(name);
    WiFiClient_WriteChunk(COL1_END COL2_START INPUT_START);
    WiFiClient_WriteByte(field);
    WiFiClient_WriteChunk(INPUT_DATA);
    WriteUint8Val(val);
    WiFiClient_WriteChunk(INPUT_END SCRIPT_START);
    WiFiClient_WriteByte(field);
    WiFiClient_WriteChunk(SCRIPT_DATA);
    WriteUint8Val(val);
    WiFiClient_WriteChunk(SCRIPT_END COL2_END TR_END);
}

// simple 1-2 byte ItoA sent out
// val can only be 0-99
void WriteUint8Val(uint8 val)
{
    if(val>99)
        return;
    
    // greater than 9 means two digits
    if(val>9)
        WiFiClient_WriteByte((val/10) + '0');
    
    WiFiClient_WriteByte((val%10) + '0');
}
/* [] END OF FILE */
